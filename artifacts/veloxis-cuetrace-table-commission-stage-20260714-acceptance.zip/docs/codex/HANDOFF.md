# Codex Task Handoff

> 2026-07-14 阶段验收检查点；正式需求以已批准 spec 和 implementation plan 为准。

## 当前状态

- 按桌抽成主要本地链路已形成阶段验收包，但不宣称最终上线完成。
- 标准费率为总成本 5%（含通道费），仅以顾客最终实付球桌费为基数；外部结账不抽成。
- 支付、过期恢复、迟到成功、T+1 账单、分账/解冻 24h 熔断、退款、报表和旧收费退役均已实现。
- 球员/教练签到改为精确请求 + `table_checkin_slots` 事务槽位；支付成功才写已核验训练。

## 阶段验证

- 根任务顺序复跑 12 个 focused 测试文件：全部通过。
- 关键计数：支付 27、分账 24、对账 36、退款 35、签到访问 8、共享副本 68 份一致。
- 10 个关键 JavaScript 文件语法通过；4 个相关 JSON 由 Node 严格解析通过。
- `scripts/codex-context.ps1` 返回 `NEW_TASK_RECOMMENDED`。
- `scripts/codex-status.ps1` 仍因无有效 `HEAD` 失败：`fatal: Needed a single revision`。

## 边界与待办

- 尚未运行根任务专属 `scripts/codex-verify.ps1 -Baseline main`；只允许在最终收口时运行一次。
- 最新检查点尚需独立整体验收复审，所有 Critical/Important 必须清零。
- 尚未部署、配置生产密钥/HTTPS 回调或执行真实设备、真实支付、T+1 账单、分账和退款 UAT。
- 未执行 Git 初始化、暂存、提交、推送或合并。
- 本轮阶段收尾未删除文件；此前仅按张总明确授权删除了 3 个误建 `getPublicTableOrder` 文件，空 `lib` 目录保留。

## 下一入口

先读 `docs/table-commission-stage-acceptance-2026-07-14.md`、批准的 spec/plan 和 `docs/table-commission-deployment.md`。

建议在新的 Codex 任务继续：处理张总阶段验收反馈 → 独立整体验收复审 → 最终全仓 verifier → 真实环境 UAT 交接。
