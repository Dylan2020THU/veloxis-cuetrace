const cloud = require('wx-server-sdk');
cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV });
const db = cloud.database();
const _ = db.command;

const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const commissionOf = () => 0;

function cnToday() { const n = new Date(Date.now() + 8 * 3600 * 1000); return { y: n.getUTCFullYear(), m: n.getUTCMonth(), d: n.getUTCDate(), dow: n.getUTCDay() }; }
function key(y, m0, d) { const mm = m0 + 1; return y + '-' + (mm < 10 ? '0' + mm : mm) + '-' + (d < 10 ? '0' + d : d); }
function periodRange(period) {
  const t = cnToday();
  const toKey = key(t.y, t.m, t.d);
  if (period === 'all') return { fromKey: '', toKey: '' };
  if (period === 'week') { const back = t.dow === 0 ? 6 : t.dow - 1; const f = new Date(Date.UTC(t.y, t.m, t.d - back)); return { fromKey: key(f.getUTCFullYear(), f.getUTCMonth(), f.getUTCDate()), toKey }; }
  return { fromKey: key(t.y, t.m, 1), toKey };
}

async function fetchLessons(where) {
  let all = []; let skip = 0; const PS = 100;
  while (true) {
    const r = await db.collection('coach_lessons').where(where).skip(skip).limit(PS).get();
    all = all.concat(r.data);
    if (r.data.length < PS) break;
    skip += PS;
  }
  return all;
}

// 店主端：结清某教练当前周期待结算课时（标 settled + 写一笔结算流水）。幂等。
exports.main = async (event) => {
  const { OPENID } = cloud.getWXContext();
  const coachOpenid = event && event.coachOpenid;
  const range = periodRange((event && event.period) || 'month');
  if (!coachOpenid) return { ok: false, msg: '缺少教练' };

  const storesRes = await db.collection('stores').where({ _openid: OPENID }).get();
  const storeIds = storesRes.data.map((s) => s._id);
  if (!storeIds.length) return { ok: false, msg: '无待结算课时' };

  const where = { coachOpenid, hallId: _.in(storeIds) };
  if (range.fromKey) where.date = _.gte(range.fromKey).and(_.lte(range.toKey));
  const targets = (await fetchLessons(where)).filter((l) => !l.settled);
  if (!targets.length) return { ok: false, msg: '无待结算课时' };

  const gross = targets.reduce((s, l) => s + (Number(l.amount) || 0), 0);
  const commission = commissionOf(gross);
  const net = r2(gross - commission);

  const cRes = await db.collection('coaches').where({ _openid: coachOpenid }).get();
  const coachNickname = (cRes.data[0] && cRes.data[0].nickname) || '教练';
  const now = Date.now();

  const added = await db.collection('coach_settlements').add({
    data: {
      shopOpenid: OPENID, coachOpenid, coachNickname,
      lessonCount: targets.length, grossAmount: gross, commission, netAmount: net,
      periodFrom: range.fromKey, periodTo: range.toKey, createdAt: db.serverDate()
    }
  });
  const settlementId = added._id;

  await Promise.all(targets.map((l) =>
    db.collection('coach_lessons').doc(l._id).update({ data: { settled: true, settledAt: now, settlementId } })
  ));

  return { ok: true, netAmount: net, lessonCount: targets.length };
};
