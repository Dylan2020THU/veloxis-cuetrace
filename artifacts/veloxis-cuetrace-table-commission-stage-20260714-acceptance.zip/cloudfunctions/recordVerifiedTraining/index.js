'use strict';

exports.main = async () => ({
  ok: false,
  code: 'PRODUCT_RETIRED'
});
