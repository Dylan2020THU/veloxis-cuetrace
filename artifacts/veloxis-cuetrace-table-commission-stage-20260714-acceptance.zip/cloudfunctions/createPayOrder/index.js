// 旧店主订阅商品已下线；保留云函数名用于兼容历史客户端。
exports.main = async () => ({
  ok: false,
  code: 'PRODUCT_RETIRED',
  msg: '店主订阅商品已下线'
});
