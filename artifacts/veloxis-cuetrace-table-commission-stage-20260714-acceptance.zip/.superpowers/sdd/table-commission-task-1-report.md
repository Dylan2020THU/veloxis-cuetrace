# Task 1 Report: Verification Harness and Finance Core

## Status

`DONE`

## RED evidence

1. Command:

   ```powershell
   & 'C:\Users\15384\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe' tests\tableCommissionMath.test.js
   ```

   Result: exit `1`. The expected assertion failed with `table finance money module should exist` because `cloudfunctions/_shared/table-finance/money.js` had not been created.

2. Command:

   ```powershell
   & 'C:\Users\15384\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe' tests\tableFinanceState.test.js
   ```

   Result: exit `1`. The expected assertion failed with `table finance state module should exist` because `cloudfunctions/_shared/table-finance/state.js` had not been created.

3. Command:

   ```powershell
   & 'C:\Users\15384\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe' tests\codexVerifyUnborn.test.js
   ```

   Result: exit `1`. The expected assertion failed with `verifier should probe HEAD with an allowed failure for unborn repositories` because the verifier still called `merge-base HEAD` unconditionally.

## Files changed

- `.superpowers/sdd/table-commission-task-1-brief.md`: recorded the approved state values and transition matrix supplied by the root task.
- `tests/tableCommissionMath.test.js`: covers immutable policy, integer-fen inputs, 500-bps rounding, 95% shop net, unknown and excessive channel fees, zero/full refund, cumulative partial-refund recomputation, and yuan-text conversion.
- `cloudfunctions/_shared/table-finance/money.js`: implements integer-fen settlement and cumulative-refund arithmetic plus decimal-yuan parsing.
- `tests/tableFinanceState.test.js`: covers all approved state-machine paths, terminal-state rejection, unknown states/kinds, idempotent transitions, and deterministic WeChat-safe identifiers.
- `cloudfunctions/_shared/table-finance/state.js`: implements exact transition validation and namespaced SHA-256-based business identifiers within 32/64-character limits.
- `tests/codexVerifyUnborn.test.js`: statically verifies HEAD probing, normal/unborn branching, and continued untracked-file collection.
- `scripts/codex-verify.ps1`: detects whether `HEAD` exists; preserves merge-base/diff behavior when it does and uses empty tracked/diff data while continuing untracked checks when it does not.
- `.superpowers/sdd/table-commission-task-1-report.md`: records this handoff.

The approved minimal auditable return-shape assumption is explicit: settlement results include `policyVersion`, `paidTableFeeFen`, `actualChannelFeeFen`, `totalCostFen`, `shopNetFen`, `platformNetFen`, and `manualReview`; refund results additionally include `originalPaidFen`, `cumulativeRefundFen`, and `retainedPaidFen`.

## GREEN evidence

1. Command:

   ```powershell
   & 'C:\Users\15384\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe' tests\tableCommissionMath.test.js
   ```

   Exact result: exit `0`; stdout `table commission math ok`.

2. Command:

   ```powershell
   & 'C:\Users\15384\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe' tests\tableFinanceState.test.js
   ```

   Exact result: exit `0`; stdout `table finance state ok`.

3. Command:

   ```powershell
   & 'C:\Users\15384\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe' tests\codexVerifyUnborn.test.js
   ```

   Exact result: exit `0`; stdout `codex verifier unborn support ok`.

4. Command:

   ```powershell
   & 'C:\Users\15384\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe' --check cloudfunctions\_shared\table-finance\money.js
   ```

   Exact result: exit `0`; no stdout or stderr.

5. Command:

   ```powershell
   & 'C:\Users\15384\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe' --check cloudfunctions\_shared\table-finance\state.js
   ```

   Exact result: exit `0`; no stdout or stderr.

## Self-review

- `STANDARD_POLICY` is frozen and exactly matches `table_commission_v1`.
- Settlement rounding uses integer `BigInt` arithmetic and half-up rounding, avoiding binary floating-point drift while returning safe integer fen.
- An unknown channel fee remains `null` in both `actualChannelFeeFen` and `platformNetFen`; an excessive fee preserves negative `platformNetFen`, leaves shop net unchanged, and sets `manualReview=true`.
- Refund settlement always derives retained payment from `originalPaidFen - cumulativeRefundFen`; full refunds therefore retain zero fen and charge zero commission.
- Transition validation checks kind and both states before allowing same-state idempotency, so unknown same-state values still throw.
- Identifier outputs are deterministic, collision-resistant hashes with distinct namespaces; all emitted characters match `[0-9A-Za-z_@*-]`, trade/order IDs are at most 32 characters, and split/refund/event IDs are at most 64 characters.
- The normal-HEAD verifier path still uses the existing merge-base, tracked diff, and diff-check commands; the unborn path explicitly clears tracked/diff results and still collects untracked files for syntax, text, and named-test checks.
- Full repository verification and runtime exercise of the normal-HEAD path were intentionally left to the root task, per the delegation contract.

## Git and deletion confirmation

No Git initialization, staging, commit, checkout, reset, or other Git write operation occurred. No file was deleted. The project-required startup context/status scripts made read-only Git probes; they reported `fatal: Needed a single revision` because the repository has no `HEAD`.

## Review-fix evidence: unambiguous identifier tuples

### Root cause verification

Before changing production code, a direct reproduction returned:

```text
eventCollision=true
refundCollision=true
```

`digest()` inserted NUL between unescaped user-controlled parts. Consequently, the serialized byte sequence for `('a', 'b\0c')` was identical to the sequence for `('a\0b', 'c')` in both `financialEventId()` and `refundNoForOrder()`.

### RED

Regression assertions for both tuple pairs were added to `tests/tableFinanceState.test.js` before the implementation change.

Command:

```powershell
& 'C:\Users\15384\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe' tests\tableFinanceState.test.js
```

Exact result: exit `1`; `AssertionError [ERR_ASSERTION]: financial event IDs should distinguish tuple boundaries`. The direct reproduction above independently confirmed that the refund tuple also collided before the fix.

### Minimal implementation fix

`digest()` now serializes the namespace and every tuple part as UTF-8 byte length, a colon, and exactly that many bytes before hashing. This encoding preserves tuple boundaries even when a value contains NUL. Hash prefixes, hexadecimal output, determinism, and 32/64-character limits remain unchanged.

Test hardening added in the same review pass:

- `recalculateAfterRefund(101, 10, 0)` must retain `91` fen and recompute total cost as `5` fen.
- A known same-state transition is explicitly verified for each of `session`, `order`, `payment`, and `split`.

### GREEN

1. Command:

   ```powershell
   & 'C:\Users\15384\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe' tests\tableCommissionMath.test.js
   ```

   Exact result: exit `0`; stdout `table commission math ok`.

2. Command:

   ```powershell
   & 'C:\Users\15384\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe' tests\tableFinanceState.test.js
   ```

   Exact result: exit `0`; stdout `table finance state ok`.

3. Command:

   ```powershell
   & 'C:\Users\15384\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe' --check cloudfunctions\_shared\table-finance\money.js
   ```

   Exact result: exit `0`; no stdout or stderr.

4. Command:

   ```powershell
   & 'C:\Users\15384\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe' --check cloudfunctions\_shared\table-finance\state.js
   ```

   Exact result: exit `0`; no stdout or stderr.

Post-fix direct reproduction returned:

```text
eventCollision=false
refundCollision=false
```

Self-review found no change to the public ID shape or financial return shape. A focused usage search found no consumers of these ID helpers outside their module and tests, so changing the pre-release hash serialization has no repository migration impact. No Git write operation or file deletion occurred during this review-fix pass.
