# Task 5B Report — Table Payment Backend

## Status

Task 5B is frozen for root/independent review. The local payment backend now
contains independently deployable `createTablePayOrder`, `tablePayNotifyV3`,
and `reconcileTablePayments` functions. No real credential was loaded, no real
network request was made, and no external payment acceptance is claimed.

## TDD evidence

The focused test is `tests/tablePaymentBackend.test.js`. Accepted RED evidence
was observed before each production group:

1. `MODULE_NOT_FOUND` for the missing
   `createTablePayOrder/lib/table-payment.js` before the strict profile, exact
   JSAPI body, and five-field signer were implemented.
2. `MODULE_NOT_FOUND` for the missing `createTablePayOrder/index.js` before the
   claim/network/finalize lifecycle was implemented.
3. `MODULE_NOT_FOUND` for the missing
   `createTablePayOrder/lib/payment-transition.js` before the common success
   transition and amount/mismatch rules were implemented.
4. `MODULE_NOT_FOUND` for the correctly named `tablePayNotifyV3/index.js`
   before notification and timer reconciliation handlers were implemented.
5. `ENOENT` for `createTablePayOrder/package.json` before deployable metadata
   and local dependency copies were added.
6. A persisted null payment-profile snapshot reached `verifiedReasons` and
   threw a `TypeError` before the final fail-closed manual-review guard was
   added and copied to all three functions.
7. A valid 64-Chinese-character promotion name was classified as a mismatch
   before promotion names were measured as Unicode characters (not UTF-8
   bytes), while C0/C1 controls and names above 64 characters remain rejected.
8. A mutated existing `payment_succeeded` event was classified as a duplicate
   before every immutable event field was compared. Exact mismatch replays are
   now side-effect free, while conflicting mismatch reason snapshots move the
   order to `manual_review` with `EXISTING_MISMATCH_CONFLICT`.
9. The reconciliation handler did not pass `now` to the store before the
   production store split the scan into database-side uncertain, expired
   creating, and expired prepay-ready queries with stable ordering, de-duplication,
   and a final bounded limit.
10. A create-time verified mismatch returned `PAYMENT_ALREADY_CONFIRMED` before
    the handler began branching on the transition outcome.
11. Shared parity reported that the script still had only the original eight
    entries after the test required all 35 literal copies. The three canonical
    table-payment sources, WeChat Pay canonical guard, and 27 Task 5B entries
    were then added without removing or reordering the Task 5A entries.
12. Independent review found that the oldest 20 long-lived `NOTPAY` orders
    could still occupy every timer batch. A 25-order, two-round test reproduced
    the repeat (`00`-`04` instead of `20`-`24`) before persistent
    `nextReconcileAt` scheduling and database ordering were added.
13. A delayed timer then reproduced a concurrent schedule regression before
    the deferral transaction began comparing the expected and current
    `nextReconcileAt` value as part of its claim CAS.
14. Independent re-review found that 20 database-visible but locally invalid
    candidates could still block the page. A `20 invalid + 1 valid` two-round
    RED proved the valid order was never scanned; invalid candidates now
    advance only their claim schedule by safe CAS and never call WeChat Pay.

Every RED was followed by the minimum implementation and a focused GREEN run.

## Implemented contract

- Strict ready-profile checks cover identity/schema, all onboarding/contract/
  profit-sharing statuses, enablement booleans, immutable policy version,
  decimal `subMchid`, and exact `sp_openid`/`sub_openid` AppID rules.
- The first transaction binds one payer, stores only the approved non-secret
  payment profile snapshot, and creates
  `paymentClaim: {attemptId,status,claimedAt,leaseExpiresAt,nextReconcileAt}`.
  The adapter call occurs after that transaction; prepay finalization re-reads
  and updates only the same attempt.
- The partner JSAPI request contains exactly the approved fields, fixed
  description, immutable `quotedTableFeeFen`, CNY, the profile-selected payer
  field, and `settle_info.profit_sharing=true`.
- A valid stored prepay is re-signed for the same payer. A different payer,
  context AppID mismatch, active claim, malformed/colliding token lookup,
  disabled profile, ambiguous create, expired/uncertain/non-success query, and
  finalize race all fail closed. `prepayExpiresAt` is exactly two hours after
  the verified create response is finalized.
- Successful create/signing returns only `timeStamp`, `nonceStr`, `package`,
  `signType`, and `paySign`; no prepay ID, merchant data, adapter result, or
  order internals are returned.
- The notification handler preserves raw bytes, extracts only WeChat Pay
  security headers through the reviewed adapter, verifies freshness/signature
  before JSON parsing, requires the exact transaction-success encrypted
  envelope, decrypts AES-GCM data, decodes fatal UTF-8, and returns an empty
  204 for processed success/duplicate/mismatch. Invalid input writes nothing
  and returns an empty non-2xx response.
- Notification, create-time authoritative query, and timer query use one
  `applyVerifiedTransaction` implementation. It matches the stored snapshot,
  merchant/AppID/order/payer/trade/currency/amount/time fields, validates
  optional coupon detail, and uses one deterministic financial-event ID.
- Promotion detail names accept at most 64 Unicode characters, including
  Chinese text, reject C0/C1 control characters, and retain strict safe-integer
  amount/currency/subsidy-total validation.
- Verified coupon subsidy remains separate. `paidTableFeeFen`, 5% cost, and
  `shopNetFen` use `payer_total`; `shopSettlementFen` adds the subsidy;
  `channelFeeFen` and `platformNetFen` remain null.
- Signed identifiable mismatches create one deterministic redacted
  `payment_mismatch` event, move the order to `manual_review`, and do not close
  the session or release occupancy. Unknown/unsigned/malformed input writes
  nothing.
- Verified replay is side-effect free. Success closes only the matching
  schema-v2 session and removes only an occupancy whose full identity matches;
  an unrelated/newer occupancy remains.
- A success replay is a duplicate only when every immutable financial-event
  field and every terminal order/session snapshot field still matches. A
  conflicting success or mismatch snapshot is fail-closed into manual review.
- Create-time authoritative queries return `PAYMENT_ALREADY_CONFIRMED` only for
  `success`/`duplicate`; `mismatch` returns `PAYMENT_MANUAL_REVIEW`, and unknown
  or failed transitions require reconciliation.
- Reconciliation requires exactly the named timer event and no OPENID, scans a
  bounded batch of 20 stale awaiting/unpaid claims, passes one captured `now`
  into the store, and performs stale-state filters plus stable ordering in the
  database before merging, de-duplicating, and applying the final limit. It
  orders first by `nextReconcileAt`, signs queries with the order snapshot's
  merchant IDs, and applies local success only for a verified
  `trade_state=SUCCESS` response. Claim, prepay finalization, and uncertain
  transitions establish the first schedule; every failed/non-successful timer
  attempt advances it by five minutes in a transaction that compares order ID,
  attempt ID, status, and the previous schedule. Successful terminal states are
  not re-scheduled. A database-visible candidate that fails the stricter local
  identity/snapshot check is also rotated by `_id` and claim CAS without making
  an external query, so persistent dirty records cannot monopolize a page.

## Deployability and parity

Each of the three function directories has its own package metadata and local
copies of:

- all four reviewed `wechatpay-v3` modules, byte-identical to `_shared` and
  retaining the mandatory adapter disclaimer;
- `table-finance/money.js` and `table-finance/state.js`, byte-identical to
  `_shared`;
- canonical `_shared/table-payment/table-payment.js`,
  `payment-transition.js`, and `cloudbase-payment-store.js`, byte-identical to
  every deployed local copy.

No deployed index imports a parent `_shared` path. The timer config contains
only `reconcileTablePaymentsTimer` with `0 */5 * * * * *`. The literal sync and
parity allowlists contain 35 explicit destinations: the original eight Task 5A
copies plus 27 Task 5B copies (`3 table-payment + 2 table-finance + 4
wechatpay-v3` files for each of the three backend functions). The sync script
guards the repository root and every canonical source family before copying.

## Verification evidence

Bundled Node:

`C:\Users\15384\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe`

- `node tests/tablePaymentBackend.test.js` — exit 0, 19/19 groups, final line
  `table payment backend ok (19 tests)`.
- `node tests/tableSessionOrderFlow.test.js` — exit 0, all 10 Task 3 regression
  groups, final line `table session order flow ok`.
- `node tests/wechatPayV3Adapter.test.js` — exit 0, 44/44 reviewed adapter
  groups, final line `wechat pay v3 adapter ok (44 tests)`.
- `node tests/cloudSharedParity.test.js` — exit 0, byte parity for 35 explicit
  copies and Windows PowerShell AST parsing, final line
  `cloud shared parity ok (35 explicit copies)`.
- `node --check` for both changed tests, every JavaScript file below the three
  function directories, and all three canonical table-payment sources — exit
  0, 35 files.
- `ConvertFrom-Json` for all package/config JSON below the three function
  directories — exit 0, 4 files.

Per task instructions, the full verifier and full test suite were not run;
root owns repository-wide verification once all Task 5 slices are integrated.

## Files changed

- `tests/tablePaymentBackend.test.js`
- `tests/cloudSharedParity.test.js`
- `scripts/sync-table-finance-libs.ps1`
- `cloudfunctions/_shared/table-payment/table-payment.js`
- `cloudfunctions/_shared/table-payment/payment-transition.js`
- `cloudfunctions/_shared/table-payment/cloudbase-payment-store.js`
- `cloudfunctions/createTablePayOrder/**`
- `cloudfunctions/tablePayNotifyV3/**`
- `cloudfunctions/reconcileTablePayments/**`
- `.superpowers/sdd/table-commission-task-5b-report.md`

No file was deleted. No `.agents/**`, page/service file, Git state, or real
credential was modified. The original eight Task 5A literal sync/parity entries
remain first and in their original order.

## External acceptance boundary

These tests use injected clients and in-memory state. Deployment remains
disabled until the service-provider AppID/merchant binding, ready special
merchant, profit-sharing authorization, production notification route,
certificates/APIv3 key, published mini-program, and a real-funds pilot payment
have been validated outside this local task.
