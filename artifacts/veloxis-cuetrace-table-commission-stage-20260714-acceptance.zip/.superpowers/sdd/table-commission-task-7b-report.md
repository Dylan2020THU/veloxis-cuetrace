# Task 7B Official Bill Reconciliation Report

## Scope

Task 7B adds the reviewed WeChat Pay APIv3 bill boundary, a timer-only daily
trade-bill reconciliation function, strict official `ALL`-bill parsing and
matching, immutable raw-bill artifacts, atomic fee evidence/events, and the
CloudBase store queries needed by the workflow. It does not implement Task 7A
reporting/Hall UI or Task 8 deployment rules. No file was deleted, no live
network request or deployment was made, and the project-wide verifier was not
run.

## Adapter and artifact boundary

- Trade-bill application responses use the existing signed APIv3 response
  verification. Bill bytes are accepted only when the signed metadata says
  exact `SHA1` and the independently calculated digest matches. Invalid hash
  metadata or a mismatch carries stable internal code `BILL_HASH_INVALID`, so
  the workflow freezes candidates as `TRADE_BILL_HASH_INVALID` and defers the
  run instead of treating corruption as an ordinary download retry.
- Downloads accept only HTTPS URLs on `api.mch.weixin.qq.com` or the official
  backup host `api2.mch.weixin.qq.com`, with exact
  `/v3/billdownload/file?...` path/query signing. The original encoded query is
  not decoded and rebuilt.
- The first release requests exact `{bill_date, sub_mchid, bill_type: 'ALL'}`
  and does not request `tar_type=GZIP`.
- The shared adapter also exposes the reviewed profit-sharing bill application
  endpoint at `GET /v3/profitsharing/bills`, forwarding exact
  `{bill_date, sub_mchid}` only. Automatic profit-sharing XLSX field parsing is
  intentionally not enabled without a real official fixture.
- Verified raw bytes use deterministic path
  `finance/bills/{billDate}/{subMchid}/trade.csv` and a deterministic artifact
  identity. The artifact document records signed/calculated hashes, size,
  source metadata, storage file ID, private-visibility intent, parse status and
  lease data. Same-hash replay is idempotent; a different hash never overwrites
  the original and freezes every affected payment/refund candidate.
- Notification decryption treats omitted `resource.associated_data` as empty
  AAD and rejects a present non-string value.

## Reconciliation result

- `reconcileTableFinance` accepts only the exact configured timer event and
  rejects an `OPENID` property even when its value is empty. It reconciles the
  previous Asia/Shanghai date at 10:15 daily.
- A deterministic per-date run is transactionally claimed. A live lease blocks
  a concurrent attempt. Each profile renews the run lease. One expired older
  date is resumed before the current date in the same invocation, so backlog
  recovery does not suppress the current bill.
- Statement creation, transport/download, artifact-claim/upload/active/CAS and
  parse retry states do not complete the date. They persist a last-attempt
  summary and leave the run `running` under a bounded deferred lease.
- `NO_STATEMENT_EXIST` is a normal completed result only when the merchant has
  no local payment/refund candidates. With local candidates it freezes them as
  `TRADE_BILL_MISSING_WITH_LOCAL_CANDIDATES`. Permanent access/auth failures
  freeze candidates as `TRADE_BILL_ACCESS_FAILED`. Anomaly or freeze-write
  failure is not swallowed; the run cannot be marked complete.
- Ready profiles are selected by exact schema/status/policy and stable `_id`
  order. Reconciliation accepts both boolean values for `paymentEnabled` and
  `profitSharingEnabled`, allowing rollback-disabled profiles to remain
  reconcilable; new-payment creation remains true-only.
- Refund candidates are scoped by immutable top-level `subMchid` and use
  official `refundCreatedAt` first, falling back to `requestedAt` only when the
  official time is null. To close the cross-midnight notification-only case,
  each strictly parsed bill also supplies at most 100 deterministic platform
  `refund_*` IDs for exact server-side document lookup and exact `subMchid`
  filtering. No notification-envelope time or date is guessed. Successful
  matching stores the signed bill provenance and enriches a previously-null
  creation time from that exact bill row, so an older requested-date retry no
  longer selects it.

## Strict matching and atomic finance evidence

- The parser requires the exact 27-column official `ALL` header, strict UTF-8
  CSV/summary structure, official calendar timestamps and exact signed fen
  conversion. It does not use floating point for money.
- A payment must have one unique, non-conflicting successful CNY row matching
  transaction ID, merchant order number, special-merchant ID, time and
  immutable amount/coupon snapshots. A same-day refund row is not counted as a
  duplicate payment row.
- A refund must match deterministic merchant and WeChat refund IDs, the same
  special merchant, official creation date/time, signed negative fee and exact
  requested amount. Local terminal success plus verified notification/query
  source is mandatory. A notification-only success may omit local refund
  creation time and settlement amount. Candidate selection falls back to
  immutable request time; the matching signed bill row is authoritative for
  its exact date/time and settlement amount. If local query-enriched values are
  present they must match exactly.
- Every unresolved or non-terminal refund blocks final confirmation. Valid
  payment evidence is still persisted while refund evidence is pending, so a
  later refund-date run can finish without losing the payment artifact.
- Confirmed channel fee is the positive payment fee plus deduplicated negative
  refund fees. Coupon/recharge-coupon evidence remains pilot-blocked. The exact
  integer fee-rate guard blocks a fee above 5%, and fee above total cost
  preserves the actual fee while exposing zero platform net for display.
- Order evidence and the deterministic append-only `channel_fee_confirmed`
  event are written in one transaction with an order snapshot CAS. Same
  evidence is idempotent; later refund evidence appends a new event. Existing
  non-finance manual-review ownership/reason metadata is preserved by every
  finance block branch.
- The generated Task 7B fee event is accepted by Task 6A settlement assessment,
  including sorted unique artifact tuples and payment/refund row evidence.

## Required CloudBase indexes

The production queries are deliberately bounded and require these composite
indexes in Task 8/deployment configuration (all order fields ascending unless
the platform expresses equality fields without a direction):

- `finance_reconciliation_runs`:
  `status, leaseExpiresAt, billDate`;
- `shop_payment_profiles`:
  `schemaVersion, status, policyVersion, _id`;
- `shop_orders`:
  `schemaVersion, paymentProfileSnapshot.subMchid, paidAt, _id`;
- `shop_refunds` official-date query:
  `subMchid, refundCreatedAt, _id`;
- `shop_refunds` requested-date fallback:
  `subMchid, refundCreatedAt, requestedAt, _id`;
- `shop_refunds` per-order transaction query:
  `orderId, _id`;
- `finance_anomalies` Task 8 action queue:
  `status, billDate, severity`.

## Storage privacy deployment gate

`storageVisibility: 'private'` is persisted as audit intent, but CloudBase
storage privacy is enforced by deployment rules rather than an unsupported
`uploadFile` metadata argument. Task 8 must install and verify a deny-client
rule for `finance/bills/**`: mini-program/client identities may neither read nor
write; only the Cloud Function/admin service identity may upload and read these
raw financial artifacts. Task 7B does not invent a non-existent SDK privacy
parameter.

## TDD and focused verification evidence

The reconciliation RED phase exposed absent old-date recovery, transient runs
being completed, and valid payment evidence being lost while refund evidence
was pending. Review-driven RED cases additionally covered statement error
classification, exact-plus-conflicting rows, per-merchant official refund
dates, null notification settlement, unresolved refunds, artifact conflict
freeze, the exact 5% guard and foreign manual-review preservation.

After the minimal fixes, the bundled Node runtime produced these exit-0 results:

- `tests/tableReconciliation.test.js`: 31 tests;
- `tests/wechatPayV3Adapter.test.js`: 48 tests;
- `tests/cloudSharedParity.test.js`: 68 explicit deployable copies;
- `tests/tableProfitSharing.test.js`: 12 tests;
- `tests/tableRefunds.test.js`: 29 tests;
- `tests/tablePaymentBackend.test.js`: 19 tests;
- `node --check` for the changed reconciliation handler and canonical store.

The sync script reported `TABLE_FINANCE_SYNC_OK copied=68`. The full verifier,
Git operations and live WeChat Pay calls remain reserved for the root task.

## Independent review

The same independent reviewer completed a final lifecycle re-review after all
review-driven RED/GREEN corrections and reported:

- Critical: 0;
- Important: 0;
- Minor: 0;
- verdict: PASS; freeze Task 7B after the root task's single final verifier.

The reviewer specifically rechecked expired-run/current-date sequencing,
lease renewal and deferral, persistence failure behavior, artifact/hash/parse
freezing, partial payment evidence, notification-only cross-day discovery,
signed bill time/hash authority, candidate bounds, immutable event behavior and
foreign manual-review preservation.

## External UAT and deployment gates

- Verify real next-day partner trade-bill availability for each pilot special
  merchant and freeze an official raw `ALL` fixture against the parser header.
- Verify the production deny-client storage rule and all listed database
  indexes before enabling the timer.
- Exercise a real pilot payment, same-day and cross-day refund, signed channel
  fee, and subsequent profit-sharing eligibility with finance operations.
- Confirm operational alerting for deferred runs, blocking anomalies and bill
  access/configuration failures.
