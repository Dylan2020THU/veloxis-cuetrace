# Task 7 Brief — Official Bills, Reconciliation, Reporting, and Hall UI

## Objective

Implement Task 7 with official signed bill evidence as the only source of
actual channel fees, expose financially unambiguous reports, and replace the
Hall's local-price close flow with the approved trusted checkout flow.

Do not delete files, edit `.agents/**`, deploy, use real credentials, make live
network calls in tests, run the full verifier, or use Git.

## Adapter and download contract

Before workflow code, extend the reviewed APIv3 adapter and tests with
`GET /v3/profitsharing/bills`. Preserve exact shared-copy parity.

- Bill-application responses must pass APIv3 response verification.
- Download only an official `https://api.mch.weixin.qq.com/...` or approved
  backup-host URL after strict URL normalization. Sign its complete original
  `path?query`; do not decode and rebuild the query.
- The bill file response itself has no WeChat response signature. Accept bytes
  only after exact `hash_type === 'SHA1'` and hash verification against the
  signed application response.
- Do not request `tar_type=GZIP` in the first release. Store/parse the verified
  raw CSV bytes only.
- Add no generic arbitrary-URL downloader.

## Timer and daily lease

`reconcileTableFinance` is internal/timer-only: reject any `OPENID`; require
exact `Type: 'Timer'` and `TriggerName: 'reconcileTableFinanceTimer'`. Configure
the timer for Asia/Shanghai 10:15 daily (`0 15 10 * * * *`), after official
10:00 bill generation, and reconcile the previous bill date.

Use deterministic `finance_reconciliation_runs/{policyVersion__billDate}` and
a transactionally claimed bounded lease. One live run per date is allowed;
expired claims may resume. Never hold a transaction during network or storage
operations.

## Artifact contract

For every ready special merchant, request the partner trade bill with exact
`bill_type=ALL`, `bill_date`, and `sub_mchid`. Micro/special merchants whose
per-sub-merchant bill mode is not verified are excluded from automatic pilot
settlement and produce an explicit anomaly.

- Store verified raw bytes privately at
  `finance/bills/{billDate}/{subMchid}/trade.csv`.
- Use a deterministic artifact ID by policy/date/type/scope/account. Persist
  source metadata, signed hash, independently calculated hash, byte length,
  storage file ID and parse status.
- Replaying the same verified SHA1 is side-effect free. A different SHA1 for
  the same artifact is a conflict anomaly and must not overwrite the original
  file/document.
- The service-provider fund bill has no `sub_mchid`; it is only supporting
  service-provider-account evidence and never proves a shop's receipt.
- A profit-sharing bill can be archived, but automatic field parsing remains
  disabled until a real official fixture freezes its exact XLSX-documented
  header. Do not guess missing field names.

## Strict trade-bill parsing and matching

Parse UTF-8 CSV with the reviewed strict parser, tolerating only the official
summary separator rules. The exact `ALL` header is:

`交易时间,公众账号ID,商户号,特约商户号,设备号,微信订单号,商户订单号,用户标识,交易类型,交易状态,付款银行,货币种类,应结订单金额,代金券金额,微信退款单号,商户退款单号,退款金额,充值券退款金额,退款类型,退款状态,商品名称,商户数据包,手续费,费率,订单金额,申请退款金额,费率备注`

Payment evidence must be exactly one row matching all of:

- `交易状态 === 'SUCCESS'`;
- `商户订单号 === outTradeNo`;
- `微信订单号 === wechatTransactionId`;
- `特约商户号 === paymentProfileSnapshot.subMchid`;
- `货币种类 === 'CNY'`;
- official order amounts equal the order's immutable WeChat snapshots.

Missing, duplicate, malformed or conflicting rows are never guessed. Create an
anomaly, set `financeAutomationBlocked=true`, and move the order to
`manual_review` without overwriting payment truth.

For the first release, automatic settlement additionally requires
`代金券金额 === 0` and `充值券退款金额 === 0`. Non-zero coupon bill fields remain
pay-valid but finance-automation-blocked until the bill allocation contract is
piloted; do not conflate them with `payer_total`.

`channelFeeFen` is the exact signed `手续费`: the unique successful payment row
is positive, and each terminal successful refund row is negative. Aggregate
refund rows only after matching deterministic merchant refund number and WeChat
refund number, and deduplicate them. A refund appears in a bill when accepted
and its status is not later updated there, so notification/query terminal truth
is also mandatory. A missing negative fee row or non-terminal refund blocks
final reconciliation.

## Atomic finance result

When all evidence matches, update the order snapshot and append the deterministic
`channel_fee_confirmed` event in one transaction. The event ID includes order and
artifact hash. Replaying identical evidence creates neither a second event nor a
second settlement claim; later verified refund-fee evidence appends a new event
instead of mutating history.

Calculate `platformNetFen = totalCostFen - channelFeeFen` only from confirmed
evidence. If the result is negative, preserve the actual fee, set platform net
to zero for display, create an anomaly and block automation because the platform
absorbs the excess. Missing/conflicting evidence, bill hash conflict, unknown
refund state, fee above 5%, or unresolved split evidence freezes split, unfreeze,
split-return and refund financial completion.

## Reporting contract

Modify revenue and business-overview functions without mixing yuan and fen:

- `legacyRevenueYuan`: historical records without schema-v2 finance semantics;
- `platformPaidFen`: final retained payer cash for verified platform orders;
- `externalPaidFen`: final table fee for `external_paid` only;
- `platformCoverageBps = round(platformPaidFen * 10000 /
  (platformPaidFen + externalPaidFen))`, or zero for a zero denominator;
- `shopNetTargetFen`: final retained payer cash less 5% total cost, never named
  actual/settled because the fund bill cannot prove per-shop receipt;
- confirmed `totalCostFen`, `channelFeeFen`, `platformNetFen`, manual-review
  amount and external-reason distribution as distinct fields.

Keep former `total` only as display-yuan compatibility output; it is never used
in finance calculations. Exclude `awaiting_payment`. Legacy records are not
silently reclassified as new platform/external orders.

## Hall checkout contract

- Owner close action sends only `{sessionId}` to `createTableOrder`; the server
  quote is displayed without client-side amount calculation.
- Use the first-response token with owner-only `genTableCheckoutCode`, display
  its bounded in-memory PNG, and poll `getTableCheckoutOrder` for verified
  status. A lost token uses only the approved explicit safe rotation path.
- Both `active` and `awaiting_payment` sessions keep the table occupied. The Hall
  must not start a new session or render the table free until verified success
  closes the matching session/occupancy.
- External settlement is a clearly separate owner-only sheet. It requires a
  bounded non-empty reason and calls only `{orderId, reason}`. Its copy states
  that it is not a WeChat Pay success, has no platform commission, and does not
  automatically award verified-training benefits.
- Remove only the old local post-close training-award call that this trusted
  flow makes obsolete; do not refactor unrelated Hall behavior.

## Required focused proof

RED/GREEN tests must prove signed bill-link handling, strict download host/path,
SHA1, duplicate/hash-conflict artifacts, exact triple-identity matching, strict
amount/currency/fee signs, refund terminal gating, missing/duplicate/conflicting
rows, one date lease, anomaly/action freeze and fee-over-cost handling.

Reporting tests must prove legacy/new separation, platform/external separation,
awaiting exclusion, exact coverage and no fen/yuan mixing. Hall tests must prove
sessionId-only quoting, awaiting occupancy, QR/status polling, external reason,
no local WeChat success and no automatic training benefit.

Run the three Task 7 focused tests, affected Hall/check-in regressions, adapter
and parity tests, JavaScript syntax and changed JSON parsing. Freeze for
independent review. Real next-day bill availability and real-funds reconciliation
remain external UAT requirements.
