# Task 1 Review Package

## Baseline

- Repository state: unborn `main`; `HEAD` does not exist.
- Base: `UNBORN_PRE_TASK_SNAPSHOT` (no Git object is available).
- Head: `WORKTREE_TASK_1` (no commit was created).
- Scope rule: because every business file is untracked, Git cannot produce a meaningful task diff. The files below, at the recorded SHA-256 hashes, are the complete Task 1 review surface. Review each listed current file once; do not crawl unrelated files.

## Requested behavior and implementer evidence

- Brief: `.superpowers/sdd/table-commission-task-1-brief.md` (entire file; 71 lines; SHA-256 `a0acfbe29692d95a5a599ee027f3bf359c18b46b74882ddc757aaec5ecc0e18a`).
- Report: `.superpowers/sdd/table-commission-task-1-report.md` (entire file; 178 lines; SHA-256 `5f8cf55e961691ba02a7a4ba967435c54881e42cf2b2a7f50b0538c6aea2a070`).

## Implementation snapshot

The five created implementation/test files are new in full:

- `tests/tableCommissionMath.test.js` (116 lines; SHA-256 `21d3748a09f53ca82a039d90c03db948e7585ef11691f3e3032f9c34bfc367d1`).
- `tests/tableFinanceState.test.js` (194 lines; SHA-256 `6dceb893523406a7cb0de10c523736b216eec0a442a9d5e58a847f5d561202da`).
- `tests/codexVerifyUnborn.test.js` (41 lines; SHA-256 `cfad22eabcbf7228160f60ec938f2c1629789cc05161af465342e7a692e3a077`).
- `cloudfunctions/_shared/table-finance/money.js` (98 lines; SHA-256 `16974e2a20e94fc650607d98ad293875ddd8a705fe07a14f47fbf4364fc4a6f4`).
- `cloudfunctions/_shared/table-finance/state.js` (127 lines; SHA-256 `f1869a003e76911d877917f2bef38a99e24d07cba96816307527516771587e67`).

One pre-existing verification script was surgically modified:

- `scripts/codex-verify.ps1` (current complete file; 131 lines; SHA-256 `067c47bdd6a0e804bcd243ab2e84e86b292c8a2620708bdbb15416f2f738e5d2`).
- Task-specific hunk: current lines 51-63 probe `HEAD`, retain merge-base/diff behavior when `HEAD` exists, and initialize empty tracked/diff collections otherwise. Current lines 64-65 then collect untracked files for both paths. The rest of the current file is context needed to judge whether verification continues correctly.

The task brief was augmented only with the controller-supplied approved state matrix at current lines 17-23. The report and this package are process artifacts, not production behavior.

## Re-review delta

The first independent review found ambiguous NUL-delimited tuple hashing plus two test-coverage minors. The implementer then changed only these areas:

- `cloudfunctions/_shared/table-finance/state.js`: tuple hashing now feeds each input as an explicit UTF-8 byte length followed by a delimiter and the bytes, eliminating boundary ambiguity without changing output format or length.
- `tests/tableFinanceState.test.js`: adds regression cases for the two formerly colliding financial-event and refund tuples, plus explicit same-state idempotency coverage for every state-machine kind.
- `tests/tableCommissionMath.test.js`: adds the discriminating `original=101`, `cumulativeRefund=10`, `retained=91`, `totalCost=5` assertion.
- `.superpowers/sdd/table-commission-task-1-report.md`: appends exact RED/GREEN evidence and self-review for the fix.

## Review constraints

- Read-only review: do not edit files or run Git write operations.
- Do not trust the report; verify behavior in the listed source and tests.
- The implementer already ran the five focused commands recorded in the report. Run another command only for a specific unresolved doubt.
- Return both a spec-compliance verdict and a code-quality verdict with file:line evidence.
