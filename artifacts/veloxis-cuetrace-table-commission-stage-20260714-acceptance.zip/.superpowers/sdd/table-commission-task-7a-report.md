# Task 7A Reporting and Hall Checkout Report

## Scope

This Task 7A slice changed only reporting, Hall checkout UI, their focused tests,
and the existing mini-program data service. It did not modify the WeChat Pay
adapter, reconciliation workflow, Task 5 payment functions, shared-copy files,
`.agents/**`, deployment state, or Git state. No file was deleted.

## Reporting result

- `getTodayRevenue` and `getShopBizOverview` separate historical yuan records
  from schema-v2 finance fields in fen.
- Schema-v2 orders are queried with a bounded `checkoutAt` millisecond window
  and attributed to Beijing calendar dates from that trusted timestamp.
  Historical records continue to use their legacy `date` field. The two query
  results are merged by order identity and filtered by the appropriate date
  source, so dual-matching records are counted once and no full-history order
  scan is used.
- `paidTableFeeFen` is already Task 6's final retained payer cash. Reporting
  uses it directly for verified `complete` orders; `refundedTableFeeFen`
  remains cumulative audit evidence and is not subtracted a second time.
  `awaiting_payment` is excluded.
- `external_paid` remains a separate amount and reason distribution.
- Coverage uses `round(platformPaidFen * 10000 /
  (platformPaidFen + externalPaidFen))`, with zero for an empty denominator.
- `shopNetTargetFen` is the platform retained cash less the rounded 5% target
  cost. It is displayed as a target, not as actual or settled shop receipt.
- Confirmed cost/channel/platform-net fields and manual-review amount remain
  distinct. Former `total` is retained only as a yuan display compatibility
  field.
- The business page converts fen to yuan explicitly and labels legacy,
  platform, external, coverage, target, confirmed fee, and review fields
  separately. Offline legacy reporting keeps the same separation.

## Hall checkout result

- Closing an ordinary table calls the trusted quote boundary with only
  `{sessionId}`. It no longer sends local amount, duration, table, or store
  values and no longer calls `closeSession` first.
- The server quote is rendered as the payable amount. Only the token returned
  on the first response is kept in page memory and sent with `orderId` to the
  owner-only checkout-code function.
- The returned PNG is validated and bounded before being used as an in-memory
  data URI. The first token drives server-status polling; paid UI state only
  comes from `getTableCheckoutOrder`.
- Lost-token recovery is an explicit owner action that calls only the approved
  `{orderId, rotate: true}` path. No replacement token is fabricated or stored.
- Both `active` and `awaiting_payment` sessions render as occupied. Awaiting
  duration freezes at `checkoutAt`, and the table is not rendered free locally.
- External settlement is a separate owner sheet. It requires a trimmed 1-200
  character reason and submits only `{orderId, reason}`. The copy explicitly
  says it is not WeChat Pay success, has no platform commission, and does not
  automatically grant verified-training benefits.
- The old close-path training write was removed. The pre-existing explicit
  check-in verification action remains unchanged.

## TDD evidence

### Reporting RED

`tests/tableReporting.test.js` first failed with:

```text
legacyRevenueYuan: actual undefined, expected 12.34
```

After cloud reporting became green, page wiring separately failed because
`todayFinance` was undefined, and the data-service empty contract failed because
`legacyRevenueYuan` was undefined. Legacy open-count and offline-legacy cases
were also observed failing before their minimal fixes.

The review correction added no-`date` schema-v2 orders, a dual-matching stale
legacy-date order, Beijing midnight boundaries, and a partially refunded final
cash fixture. Its first RED was:

```text
platformPaidFen: actual 1000, expected 10000
```

This proved that the date-only query omitted the real no-`date` platform order
and admitted a schema-v2 record through its stale `date`. After implementing
the bounded `checkoutAt` query, trusted date attribution, merge, and dedupe, the
remaining RED became:

```text
platformPaidFen: actual 9000, expected 10000
```

That isolated the refund double-subtraction. Using final `paidTableFeeFen`
directly then made the focused reporting test green.

### Hall RED

`tests/hallStatusCheckoutContract.test.js` first observed the old boundary:

```text
actual: { amount, durationMin, storeId, tableId, tableName }
expected: { sessionId: 'session_1' }
```

The focused test then drove awaiting occupancy, owner QR/status polling,
reason-only external settlement, service fail-closed behavior, disclosure copy,
and removal of the old close path.

## Verification evidence

The bundled Node runtime was used because `node` was not present on the shell
PATH. The following focused/regression tests exited `0`:

- `tests/tableReporting.test.js`
- `tests/hallStatusCheckoutContract.test.js`
- `tests/hallStatusSheetLayout.test.js`
- `tests/tableCodeCheckin.test.js`
- `tests/tableCodeQrRegression.test.js`
- `tests/tableCheckoutPageContract.test.js`
- `tests/profileHeaderRole.test.js`

`node --check` also exited `0` for both new tests and all five changed JavaScript
production files. The relevant Hall/Biz page JSON and the two reporting cloud
function package JSON files parsed successfully.

The project-wide verifier was intentionally not run; final full verification is
reserved for the root task. `scripts/codex-status.ps1` could not produce a status
summary because the workspace currently has no resolvable single revision
(`fatal: Needed a single revision`).

### Review-correction verification

Using
`C:\Users\15384\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe`,
the final review-correction run produced:

- `tests/tableReporting.test.js`: exit `0`, `table reporting ok`;
- `tests/hallStatusCheckoutContract.test.js`: exit `0`;
- `tests/hallStatusSheetLayout.test.js`: exit `0`;
- `tests/tableCodeCheckin.test.js`: exit `0`;
- `tests/tableCodeQrRegression.test.js`: exit `0`;
- `tests/tableCheckoutPageContract.test.js`: exit `0`;
- `tests/tableCheckoutToken.test.js`: exit `0`, six tests;
- `node --check` for the reporting test and both reporting cloud functions:
  exit `0`;
- strict UTF-8, trailing-whitespace, and conflict-marker checks for the three
  changed JavaScript files and this report: exit `0`.

An additional `tests/tablePaymentBackend.test.js` run passed its first 18 named
checks, then exited `1` in `testBackendFunctionsAreIndependentlyDeployable`
because concurrently edited Task 5 shared/deployment copies differed byte for
byte. None of the compared Task 5 files is in this Task 7A correction scope, so
Task 7A did not modify them; the root Task 5 lane owns that parity resolution.

### Independent-review remediation

The independent review found two Task 7A defects and both were corrected with
new RED tests before production changes.

- Hall checkout had no request-generation guard around asynchronous quote and
  QR completion. The new regression starts a slow `session_1` checkout, closes
  it, completes `session_2`, and then completes the stale first request. Before
  the fix it observed an extra `{ orderId: 'ord_1', token: 'token_1' }` QR call,
  proving that the stale result crossed into the current sheet. Hall now gives
  every checkout/rotation a local generation and requires the exact generation,
  `sessionId`, `orderId`, and token before quote, QR, polling, rotation, or error
  completion may update the sheet. Closing the sheet or starting another
  checkout invalidates all earlier completions.
- `getTodayRevenue` previously converted any query failure into an `ok: true`
  zero report. The new RED expected only
  `{ ok: false, code: 'REVENUE_UNAVAILABLE' }` and instead received the old zero
  finance object. The data-service assertion separately failed with
  `Missing expected rejection` while the old zero fallback was present. The
  cloud function now returns that fixed non-sensitive error, and
  `getTodayShopRevenue` rejects it instead of presenting zero revenue;
  successful `total` compatibility is unchanged.

After both fixes, the following commands exited `0`:

- `tests/tableReporting.test.js`;
- `tests/hallStatusCheckoutContract.test.js`;
- `tests/hallStatusSheetLayout.test.js`;
- `tests/tableCodeCheckin.test.js`;
- `tests/tableCodeQrRegression.test.js`;
- `tests/tableCheckoutPageContract.test.js`;
- `tests/tableCheckoutToken.test.js` (six tests);
- `node --check` for the two changed tests and all three changed production
  JavaScript files.

## Freeze and external gates

Task 7A is frozen for root-task independent review. Real mini-program rendering,
real owner authorization, real QR scanning, real payment notification, and
next-day financial reconciliation remain external UAT/deployment gates.
