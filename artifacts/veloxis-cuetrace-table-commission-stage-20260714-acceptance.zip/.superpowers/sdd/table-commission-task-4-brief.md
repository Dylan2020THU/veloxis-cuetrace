# Task 4 Brief — WeChat Pay APIv3 Reference Adapter

## Objective

Implement the approved Task 4 APIv3 reference adapter, strict bill parser, and shared-library parity tooling with test-first development. This task must not create a real payment, use credentials, deploy, or change business state.

## Approved context

- Mainland China, ordinary service-provider mode with special merchants, APIv3.
- Node.js is not an official sample language for this project. The adapter is a reviewed reference translation from official Java guidance and must contain this exact source disclaimer:
  `AI 参考官方 Java 翻译生成，非官方维护。请开发人员自行审查 AI 生成的代码逻辑，上线前充分测试以确保其适用性与准确性，AI 不对生成代码的正确性承担责任。`
- The user already approved this reference implementation and disclaimer.
- Never read, print, or commit real keys/certificates. Tests generate ephemeral RSA fixtures in memory.
- Use Node built-ins only.

## Official references already verified by root

- `.agents/skills/wechatpay-payment-integration/assets/微信支付官网文档/APIv3/合作伙伴/通用规则/开发须知/总述-APIv3如何签名和验签-4012365870.md`
- `.agents/skills/wechatpay-payment-integration/assets/微信支付官网文档/APIv3/合作伙伴/通用规则/开发须知/如何解密微信支付回调报文/如何解密回调报文和平台证书-4012082320.md`
- `.agents/skills/wechatpay-payment-integration/assets/微信支付官网文档/APIv3/合作伙伴/通用规则/开发须知/如何签名/如何构造调起支付签名/小程序调起支付签名-4012365869.md`

Do not edit `.agents/**`.

## Files in scope

- Create `tests/wechatPayV3Adapter.test.js`
- Create `cloudfunctions/_shared/wechatpay-v3/client.js`
- Create `cloudfunctions/_shared/wechatpay-v3/config.js`
- Create `cloudfunctions/_shared/wechatpay-v3/http-event.js`
- Create `cloudfunctions/_shared/wechatpay-v3/bill-parser.js`
- Create `scripts/sync-table-finance-libs.ps1`
- Create `tests/cloudSharedParity.test.js`
- Modify `.gitignore`
- Create `.superpowers/sdd/table-commission-task-4-report.md`

Do not touch unrelated files. Do not delete any file. Do not commit or stage.

## Required behavior

1. RED crypto tests using generated RSA fixtures for:
   - request canonical string: `METHOD\ncanonical-path-with-query\ntimestamp\nnonce\nbody\n`
   - `WECHATPAY2-SHA256-RSA2048` authorization fields and RSA-SHA256 signature
   - response/notification verification string: `timestamp\nnonce\nraw-body\n`
   - required headers, timestamp skew rejection, malformed timestamp rejection, and unknown serial rejection
   - mini-program signing string: `appId\ntimeStamp\nnonceStr\nprepay_id=...\n`
   - RSA-OAEP with SHA-1/MGF1 defaults for sensitive fields, base64 result
   - AES-256-GCM decryption: exactly 32-byte APIv3 key, final 16 bytes are auth tag, strict base64/resource validation
2. RED HTTP tests for:
   - JSON and raw byte downloads
   - non-2xx structured error parsing without treating an unverified error body as trusted
   - signature required and verified on every ordinary API response, including non-2xx responses
   - timeout/abort behavior
   - fail-closed configuration and no secret values in thrown errors
   - injectable request transport for deterministic tests; production default may use `https.request`
3. Implement exact endpoints:
   - `/v3/pay/partner/transactions/jsapi`
   - `/v3/pay/partner/transactions/out-trade-no/`
   - `/v3/refund/domestic/refunds`
   - `/v3/profitsharing/receivers/add`
   - `/v3/profitsharing/orders`
   - `/v3/profitsharing/return-orders`
   - `/v3/profitsharing/orders/unfreeze`
   - `/v3/bill/tradebill`
   - `/v3/bill/fundflowbill`
4. Configuration is read only from:
   - `WXPAY_V3_ENABLED`
   - `WXPAY_SP_APPID`
   - `WXPAY_SP_MCHID`
   - `WXPAY_MERCHANT_SERIAL_NO`
   - `WXPAY_MERCHANT_PRIVATE_KEY`
   - `WXPAY_API_V3_KEY`
   - `WXPAY_PLATFORM_CERTS_JSON`
   - `WXPAY_TABLE_NOTIFY_URL`
   - `WXPAY_TABLE_REFUND_NOTIFY_URL`
   - `WXPAY_PLATFORM_RECEIVER_NAME`
   Fail closed unless enabled and every required value is valid. Parse cert mapping strictly and reject duplicates/empty serials/invalid PEMs. Never fall back to client input.
5. Bill parser:
   - Accept official backtick-prefixed CSV, quoted fields, escaped double quotes, CRLF/LF, and a single summary line only according to tested official shape.
   - Reject malformed quotes, inconsistent columns, missing required headers, duplicate headers, unsafe/control characters, and non-exact decimals.
   - Convert signed decimal yuan to fen exactly without floating point; reject more than 2 fractional digits and unsafe integer results.
   - Validate downloaded raw bytes against `hash_type=SHA1` and case-insensitive `hash_value` before parsing; reject other algorithms/malformed hashes.
6. Secret hygiene:
   - Add `.env`, `*.pem`, `*.p12`, `*.key`, and private certificate/key directories to `.gitignore` without removing existing patterns.
7. Finance-library sync/parity:
   - PowerShell script has a hard-coded, explicit destination allowlist only. It copies canonical `cloudfunctions/_shared/table-finance/{money,state}.js` to each current deployed copy.
   - Current destinations are `cloudfunctions/createSession/lib` and `cloudfunctions/createTableOrder/lib`; discover and include any additional legitimate table-finance copy created before implementation finishes.
   - Reject arbitrary destination/path parameters. Resolve and verify every destination remains under the repository root. Do not delete anything.
   - `tests/cloudSharedParity.test.js` byte-compares each allowlisted deployed copy with the canonical source and verifies the script allowlist matches the test allowlist.

## API design/safety constraints

- Export small pure helpers needed by tests; keep the public surface minimal.
- Treat raw response bytes as the signed payload; do not reserialize JSON before verification.
- Official bill-download exception: a `download_url` response intentionally has no Wechatpay signature headers. Expose only a dedicated downloader that accepts `https://api.mch.weixin.qq.com/v3/billdownload/file?...`, rejects authority/path confusion, signs the exact raw path and query, treats non-2xx body details as untrusted, and returns raw bytes for mandatory SHA1 validation before parsing. Never expose a generic skip-verification flag. Source: official partner document `APIv3/合作伙伴/支付产品/下载账单/API列表/下载账单-4013080597.md`.
- Header matching is case-insensitive, but duplicate/conflicting security headers must fail closed.
- Verify signature and freshness before JSON parsing or surfacing WeChat error details.
- Request path used for signing must include the exact encoded query string sent on the wire.
- Use `crypto.timingSafeEqual` where comparing fixed-length digests; RSA verification uses `crypto.verify`.
- Do not log authorization, private key, APIv3 key, decrypted resource, or full callback body.
- Do not add certificate auto-download/rotation, retries, business cloudfunctions, deployment code, or speculative abstractions in this task.

## TDD and verification

1. Write tests first and run them to record a meaningful RED caused by missing behavior.
2. Implement the minimum code to pass.
3. Run only:
   - bundled Node `tests/wechatPayV3Adapter.test.js`
   - bundled Node `tests/cloudSharedParity.test.js`
   - `node --check` for files directly changed
4. Do not run `scripts/codex-verify.ps1`; root will run the full verifier once at final completion.
5. Report RED evidence, GREEN evidence, files changed, assumptions, and residual risks in the task report.

Bundled Node:
`C:\Users\15384\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe`
