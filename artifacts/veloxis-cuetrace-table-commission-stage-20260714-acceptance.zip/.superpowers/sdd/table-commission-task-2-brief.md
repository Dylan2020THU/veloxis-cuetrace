## Task 2: Retire New Legacy Charges and Coach Commission

### Files

- Create: `tests/legacyBillingRetirement.test.js`
- Create: `tests/coachCommissionRetirement.test.js`
- Modify narrowly: `tests/recurringSubscriptionGuard.test.js` only to replace obsolete active `createRecurringContract` expectations with `PRODUCT_RETIRED` plus zero-write/zero-network assertions; preserve all callback, cancellation, and `deleteAccount` historical-guard coverage.
- Modify only the Task 2 files listed in `docs/superpowers/plans/2026-07-14-table-commission-billing-implementation.md` under Task 2.
- Report: `.superpowers/sdd/table-commission-task-2-report.md`

### Binding business requirements

- The former shop subscription product is retired. Every current shop feature is free and must not open a paywall.
- Preserve public billing/client function names as compatibility interfaces, but `canUse(...)`, `hasPlan(...)`, `isPlanActive(...)`, and `requirePlan(...)` must allow access; `getPlanList(...)` and purchase option lists must be empty; active purchase helpers must fail closed with `{ ok: false, code: 'PRODUCT_RETIRED' }` and must not mutate local state.
- `upgradePlan`, `createPayOrder`, `createVirtualPayOrder`, `createRecurringContract`, and `createRecurringDebit` cloud functions must return `{ ok: false, code: 'PRODUCT_RETIRED' }` before any database write or payment/network call. Additional human-readable fields are allowed, but `ok` and `code` are exact.
- `cloudfunctions/createRecurringDebit/config.json` must remain as a file but contain no active trigger. Do not delete any callback, cancellation, historical order, subscription, or settlement file.
- No shop dashboard/profile/brand-creation path may display or invoke subscription, renewal, trial-expiry, purchase, signing, or virtual-payment UI. The global `paywall` compatibility entry must allow the caller immediately instead of mounting a payment component. Remove the delegated-signing mini-program allow-list entry from `app.json` because it is no longer used.
- Remove `FORCE_VIRTUAL_PAY_FOR_TEST` and every executable purchase/signing branch from the paywall component. Preserve the component API as a harmless compatibility no-op.
- Existing billing/history reads may remain for backward-readable data, but must not create, renew, sign, debit, or grant new subscription entitlements.
- Coach commission for all newly created or currently unsettled business is zero. New coach bookings must omit `commissionRate`; `COACH_COMMISSION_RATE`/`calcCoachCommission` compatibility exports may remain but must evaluate to zero.
- Current unsettled settlement values must be `commission = 0` and `net = gross` in overview, detail, and settlement creation.
- Do not rewrite already settled historical snapshots: existing `coach_settlements.commission` and `coach_settlements.netAmount` remain authoritative when historical totals are shown. Do not recompute them at zero or at 5%. New settlement documents may retain the existing snapshot fields with `commission: 0` and `netAmount: gross`.
- `recordVerifiedTraining` represents a table-session verification flow. Any coach lesson it creates must persist `amount: 0`; never copy the table fee from the event into coach revenue.
- Remove visible `抽佣5%`, coach `平台服务费`, subscription/renewal, and paid-membership copy from the Task 2 UI/legal files. Do not alter unrelated legal/privacy text.
- Repository is unborn. Do not initialize Git, stage, commit, or delete files. Preserve unrelated files and match existing style.

### TDD and implementation steps

1. Write `tests/legacyBillingRetirement.test.js` first. It must behaviorally verify free shop access and compatibility interfaces, fail-closed client purchase helpers without local/cloud mutation, all five fail-closed cloud endpoints without database writes/payment calls, empty recurring triggers, absence of visible renewal/purchase hooks in the listed shop/profile/app/paywall files, absence of `FORCE_VIRTUAL_PAY_FOR_TEST`, and continued presence of cancellation/callback files.
2. Run the new legacy test with the bundled Node runtime and capture the expected RED output against current behavior.
3. Make the minimum subscription-retirement changes. Do not delete former product files.
4. Rewrite `tests/shopSubscriptionPlans.test.js` and `tests/recurringCloudFunctions.test.js` expectations to assert retirement and compatibility rather than active sales.
   The approved plan also asks `tests/recurringSubscriptionGuard.test.js` to remain green, but its original active-signing assertions conflict with retirement. Migrate only those obsolete create-contract cases to retirement assertions; do not weaken callback/cancellation/history tests.
5. Write `tests/coachCommissionRetirement.test.js` first for the coach path. It must verify new booking data omits `commissionRate`, mock booking data omits it, current unsettled commission is zero and net equals gross, newly created settlement snapshots use zero commission, historical settled snapshot values remain authoritative, table-session verified training records coach amount as zero, and listed UI/legal copy no longer advertises 5% commission/service fees.
6. Run the coach test and capture the expected RED output against current behavior.
7. Make the minimum coach-retirement changes.
8. Run focused GREEN checks with the bundled Node executable:

```powershell
& 'C:\Users\15384\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe' tests\legacyBillingRetirement.test.js
& 'C:\Users\15384\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe' tests\coachCommissionRetirement.test.js
& 'C:\Users\15384\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe' tests\shopSubscriptionPlans.test.js
& 'C:\Users\15384\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe' tests\recurringCloudFunctions.test.js
& 'C:\Users\15384\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe' tests\recurringSubscriptionGuard.test.js
& 'C:\Users\15384\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe' tests\accountDeletionGracePeriod.test.js
```

9. Run `node --check` with the bundled runtime for every JavaScript file changed by Task 2.

### Scope notes

- Do not implement table checkout, APIv3, profit sharing, refunds, or reporting in this task.
- Do not refactor unrelated account, theme, mock, or navigation code.
- Do not remove historical fields or migrate old documents.
- If a former UI handler must remain because WXML or another compatibility caller references it, make it immediately allow/no-op; do not leave a route to a retired purchase action.

### Report contract

Write `.superpowers/sdd/table-commission-task-2-report.md` with:

- status `DONE`, `DONE_WITH_CONCERNS`, `NEEDS_CONTEXT`, or `BLOCKED`;
- exact RED commands, exit codes, and why each failed;
- files changed and concise behavior summary;
- exact GREEN/focused commands and pass/fail summary;
- syntax-check summary;
- self-review, including confirmation that every active charge path fails before writes/network and historical settled snapshots are preserved;
- confirmation that no Git write and no file deletion occurred.
