# Task 8 Brief — Deployment Contract and Final Verification

## Objective

Close the approved table-commission implementation with a static deployment
contract, operator documentation, whole-change independent review, and one
root-owned final verifier run. This task documents deployment; it does not
deploy, publish, configure merchant consoles, or move real money.

No file may be deleted without Zhang's explicit permission. Do not edit
`.agents/**`, expose secrets, stage/commit, or initialize Git.

## Static deployment test

Create `tests/tablePaymentDeployment.test.js` RED first. It must require every
approved function/page/package/config and reject:

- missing production entrypoints or package metadata;
- deployed imports that escape their cloud-function directory;
- drift from canonical shared modules or the literal sync allowlist;
- missing mandatory APIv3 adapter disclaimer;
- secret-looking literals, private keys, APIv3 keys, merchant certificates or
  bearer checkout tokens in source/config/docs;
- active subscription/recurring-payment/coach-settlement triggers;
- client-side payment success, client price/merchant/payer fields, or direct
  finance collection writes;
- callback handlers that do not preserve raw body and Wechatpay headers.

Require exact timers/configs implemented by Tasks 5–7, including
`reconcileTablePaymentsTimer`, `settleTableProfitSharingTimer`, and
`reconcileTableFinanceTimer`, with one unambiguous schedule each. The deployment
test must parse every changed JSON file rather than regex-only checking it.

## Operator documentation

Create `docs/table-commission-deployment.md` and update `README.md` only where
needed. Document:

- ordinary service-provider onboarding, special-merchant onboarding,
  profit-sharing authorization and receiver relationship;
- payment-profile schema and per-shop enable/disable workflow;
- every `WXPAY_*` environment variable, including encryption-key selection,
  with placeholders only and secret-storage guidance;
- HTTPS callback exposure for payment and refund notifications, preserving
  untouched bytes and required `Wechatpay-*` headers;
- CloudBase function list, public/internal/owner-only access classification,
  timer names/schedules/timezone, storage paths and private permissions;
- collections and compound indexes required by payment, refund, split, bill,
  anomaly, event and reporting queries;
- deterministic IDs, append-only finance events, artifact retention and PII/
  secret logging prohibitions;
- rollback: disable new claims at payment profiles while keeping credentials,
  callbacks, query, refund and reconciliation alive for in-flight orders;
- a recovery runbook for uncertain payment, bill conflict, fee above 5%, split
  failure, return failure, refund mismatch and manual-review release.

Required collections include the existing session/order/occupancy/store data
plus `shop_payment_profiles`, `financial_events`, `shop_refunds`,
`wechat_bill_artifacts`, `finance_reconciliation_runs`, and
`finance_anomalies` (and any exact Task 6 collection actually implemented).
Document least privilege: clients never write finance truth directly.

Required indexes must at least cover:

- unique/deterministic lookup of checkout-token hash, out-trade number and
  transaction ID;
- payment reconciliation by schema/status/claim expiry;
- settlement by sub-merchant/payment/split/paid time;
- reporting by shop/schema/order status/checkout time;
- refunds by order/status and deterministic refund number;
- financial events by order/type/time;
- anomalies by status/date/severity;
- sessions by shop/store/status.

Use actual implemented field names and exact index order; do not leave schematic
placeholders in the final document.

## Release gates and real-funds boundary

The default release remains disabled until all of these are externally true:

- service-provider application approved;
- special merchant onboarded and payment/profit-sharing contracts authorized;
- service-provider AppID/MchID binding and OPENID mode verified;
- production merchant private key, APIv3 key and trusted public key/certificates
  installed in secret storage;
- both HTTPS callbacks reachable with raw-body forwarding;
- mini-program checkout page published and code path verified on a real device;
- finance/legal/tax review signed off;
- one real small payment followed by signed query/notification, next-day trade
  bill, actual fee reconciliation, split/query/unfreeze, partial refund/return,
  full refund and subsequent negative fee row has passed.

Local tests may establish code behavior only. They never claim merchant-console,
network, published-client, official next-day bill or real-money acceptance.

## Whole-change review and verification

1. Run the deployment focused test, all Task 1–7 focused regressions, sync, parity,
   JavaScript syntax and JSON parsing as appropriate while remediating.
2. Use an independent whole-change review. Every Critical/Important finding gets
   a focused RED regression, implementation fix and re-review.
3. Use verification-before-completion. Prepend the bundled Node directory to
   `PATH`, then root runs exactly once:

   `& .\scripts\codex-verify.ps1 -Baseline main`

4. Require `STATUS=PASS` for every verifier section. Separately parse every
   changed JSON and inspect the final untracked inventory because this repository
   has no HEAD/baseline commit.
5. Update `docs/codex/HANDOFF.md` and `.superpowers/sdd/progress.md` with exact
   local evidence, no-deletion status, any retained user files, and the external
   UAT gates above.

Notify Zhang for acceptance only when local code, focused/full verification and
Critical/Important review are all clean. State separately that real-funds UAT is
still pending until the external gates are executed.
