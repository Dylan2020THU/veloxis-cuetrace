# Task 5 Brief — Customer Checkout and Verified Payment Lifecycle

## Objective

Implement the approved Task 5 contract in
`docs/superpowers/plans/2026-07-14-table-commission-billing-implementation.md`
with focused TDD. A table is released only after a signed, decrypted, fully
matched WeChat Pay success notification or a signed successful query result.

This task must not make a real network call in tests, edit `.agents/**`, delete
files, run the full `scripts/codex-verify.ps1`, stage, commit, or initialize Git.

## Required scope

Use the files listed by Task 5, plus only these necessary additions:

- Modify `cloudfunctions/createTableOrder/index.js` and its focused regression
  test to issue the checkout token with the order.
- Modify `cloudfunctions/markTableOrderExternalPaid/index.js` and its focused
  regression test so an external settlement cannot win after any platform-pay
  claim or uncertain platform-pay attempt.
- Add small canonical pure modules under
  `cloudfunctions/_shared/table-payment/` when they are used by at least two
  Task 5 functions.
- Add deployable byte-identical copies of required `wechatpay-v3`,
  `table-finance`, and `table-payment` modules inside each independently
  deployed cloud function. No deployed function may import a parent
  `cloudfunctions/_shared` path.
- Add an explicit-copy sync script and a parity test. The allowlist must be
  literal, accept no path arguments, reject path escapes and every ancestor
  reparse point before writing, and never delete anything.

Keep the implementation small. Do not add AA payment, token storage in clear
text, a payment-profile management UI, coupons issuance, refunds, profit
sharing, channel-fee recognition, or reconciliation reports in this task.

## TDD order

1. Add focused RED tests for the contract below and record the actual failure.
2. Implement the smallest behavior that makes each group green.
3. Run `tests/tablePaymentFlow.test.js`, Task 3 regressions affected by the
   order/external-pay changes, the shared-copy parity test, and `node --check`
   for every changed JavaScript file.
4. Freeze the implementation for independent review. Do not self-declare the
   overall feature complete.

## Checkout token

- Generate exactly 16 cryptographically random bytes once per new order
  invocation and encode them as 22-character unpadded base64url text.
- Token validation must decode exactly 16 bytes and re-encode to the identical
  canonical text; a regex-only 22-character lookalike is not sufficient.
- Persist only the lowercase 64-hex SHA-256 digest in
  `checkoutTokenHash`; never persist or log the plaintext token.
- Return the plaintext token only in the successful first-create response,
  separate from the public quote. An idempotent read of an already-created
  order must not invent, rotate, or reveal a token.
- Bind the hash to exactly one schema-v2 order. Token lookup uses SHA-256 and a
  limit of two; zero or multiple matches return the same generic not-found
  failure.
- `genTableCheckoutCode({orderId, token})` is owner-authenticated, verifies the
  token digest and order ownership/state, and embeds only `t=<token>` in the
  `pages/table-checkout/index` scene. The scene is at most 32 characters. The
  page and code parameters are fixed server-side. Return the generated PNG as
  bounded in-memory/base64 data for the owner UI; do not permanently upload a
  bearer-token QR artifact or accept a client-selected page/path.
- To recover from a lost first-create response without weakening hash-only
  storage, the same owner-only function may accept the exact explicit form
  `{orderId, rotate: true}` only while the order is unpaid, unbound, and has no
  platform-payment attempt. It atomically replaces the hash with a new
  128-bit token, embeds that token directly in the returned code, and returns
  no plaintext token. It must never rotate implicitly on an idempotent
  `createTableOrder` retry or after payment claiming begins.
- Direct page options and decoded `scene` input may supply the token. Reject
  every other token shape before database access.

## Public checkout read

`getTableCheckoutOrder({token})` is a bearer-capability read and returns only:

- store display name, table display name;
- start/checkout time, billed duration, snapshotted hourly price;
- table gross, table discount, quoted payable table fee;
- order/payment status and a derived `canPay` boolean.

It must not return owner/shop IDs, payer OPENID, `outTradeNo`, sub-merchant
data, transaction IDs, checkout-token hashes, financial internals, or payment
credentials. Paid/terminal orders may be read for status but cannot be paid
again.

## Immutable quoted amount and coupon accounting

- Add `quotedTableFeeFen = tableGrossFen - tableDiscountFen` when the order is
  created. The APIv3 order amount always uses this immutable field and must be
  a positive safe integer.
- Before verified payment, `paidTableFeeFen` may equal the quote for existing
  order-state compatibility. Matching after payment must use
  `quotedTableFeeFen`, never a mutable settlement field.
- A verified WeChat result must contain safe integer `amount.total` and
  `amount.payer_total`, with `total === quotedTableFeeFen` and
  `0 <= payer_total <= total`, and both currency fields equal to `CNY`.
  If `promotion_detail` is present, validate its structure and require its
  coupon amounts to reconcile to `total - payer_total`; a malformed or
  inconsistent detail enters manual review. Absence of this optional detail
  does not override the signed `total/payer_total` difference.
- On verified success set:
  - `wechatOrderTotalFen = amount.total`;
  - `wechatPayerTotalFen = amount.payer_total`;
  - `couponSubsidyFen = amount.total - amount.payer_total`;
  - `paidTableFeeFen = amount.payer_total`;
  - `totalCostFen` and `shopNetFen` recalculated from `paidTableFeeFen` under
    the immutable 500-bps policy;
  - `shopSettlementFen = shopNetFen + couponSubsidyFen`.
- Coupon subsidy remains separate and never enters the commission base.
  `channelFeeFen` and `platformNetFen` remain `null` until official-bill
  reconciliation in a later task.

## Payment profile

Load `shop_payment_profiles/{shopId}` server-side. It is ready only when all of
these exact checks pass:

- `_id === shopId`, `shopId` matches the order, and `schemaVersion === 1`;
- `status === 'ready'`, `onboardingStatus === 'approved'`,
  `contractStatus === 'signed'`, and
  `profitSharingAuthorizationStatus === 'authorized'`;
- `paymentEnabled === true` and `profitSharingEnabled === true`;
- `policyVersion === order.policyVersion === 'table_commission_v1'`;
- `subMchid` is 8–32 decimal digits;
- `openidMode` is exactly `sp_openid` or `sub_openid`;
- `subAppid` is absent/empty for `sp_openid`, and is a valid AppID and required
  for `sub_openid`.

No credential, private key, APIv3 key, or certificate is stored in this
collection.

The first successful payment claim persists an immutable, non-secret
`paymentProfileSnapshot` on the order containing only the matched service
provider AppID/merchant ID, optional sub-AppID, sub-merchant ID, OPENID mode,
profile schema version, and policy version. Later callback/query validation
uses this order snapshot. Disabling or changing the current profile must stop
new claims but must not make an already-created real WeChat payment
unrecognizable.

## One payer and create-pay concurrency

- `createTablePayOrder` accepts exactly `{token}`. It derives the authenticated
  `OPENID` and `APPID` from `cloud.getWXContext()`; it accepts no client amount,
  order ID, shop ID, payer ID, or merchant field.
- In a transaction, the first caller permanently binds `payerOpenid`, validates
  the full awaiting-payment order/session relationship, snapshots the ready
  payment profile, and creates a random attempt/lease claim. A different payer
  is always rejected.
- `APPID` must match the AppID whose OPENID field will be used: service-provider
  AppID for `sp_openid`, profile `subAppid` for `sub_openid`.
- Never hold a database transaction open across the WeChat network call.
  Claim, call the adapter, then transactionally finalize only the same attempt.
- A stored valid `prepayId` for the same payer is idempotently re-signed for the
  mini program. An active claim returns a retryable creating result. An
  ambiguous transport outcome is marked uncertain and is not treated as
  payment success; reconciliation is authoritative.
- Persist a two-hour `prepayExpiresAt` consistent with the official JSAPI
  contract. An expired prepay or ambiguous create result must be queried before
  any retry. `SUCCESS` uses the verified transition; confirmed
  `ORDER_NOT_EXIST` may release the create claim for the same deterministic
  request; every other remote state fails closed for reconciliation/manual
  handling. Do not promise indefinite re-creation with the same
  `outTradeNo`, and do not invent a second charge identifier in this task.
- Any platform-payment claim/attempt, including uncertain state, makes
  owner-side `markTableOrderExternalPaid` fail. The external-pay operation and
  the first platform-pay claim must be mutually exclusive transactions.

## Exact partner JSAPI request

Use the reviewed APIv3 adapter and configuration. The JSON body is exactly the
required supported fields:

- `sp_appid`, `sp_mchid`, optional `sub_appid`, `sub_mchid`;
- a fixed safe description (`CueTrace球桌费`), deterministic `out_trade_no`,
  configured HTTPS `notify_url`;
- `amount: { total: quotedTableFeeFen, currency: 'CNY' }`;
- `payer: { sp_openid: OPENID }` or `{ sub_openid: OPENID }` according to the
  ready profile;
- `settle_info: { profit_sharing: true }`.

Validate the verified response contains only a usable non-empty `prepay_id`
for finalization. Return to the client only the five signed
`wx.requestPayment` fields: `timeStamp`, `nonceStr`, `package`, `signType`, and
`paySign`. Sign with the matching payer AppID. Do not return `prepay_id`,
merchant data, order internals, config, or adapter responses.

The mandatory approved adapter disclaimer must remain present in every exact
deployed copy through byte parity; do not hand-edit copies independently.

## Verified success input

Both notification and query paths normalize to one pure verified-transaction
contract and call the same idempotent database transition.

Notification path:

- Take untouched raw HTTP bytes and only `Wechatpay-*` security headers.
- Verify signature/freshness before JSON parsing, then require outer
  `event_type === 'TRANSACTION.SUCCESS'`,
  `resource_type === 'encrypt-resource'`, and
  `resource.original_type === 'transaction'`.
- AES-GCM decrypt with the configured APIv3 key, decode fatal UTF-8, then parse
  JSON. Invalid input writes nothing and never exposes secrets in the response
  or logs.
- A valid duplicate returns HTTP 200/204 with no response body. Invalid or
  temporarily unprocessed input returns a non-2xx response without echoing the
  raw payload.

Query path:

- `reconcileTablePayments` accepts only a context with no `OPENID` and the
  exact timer event `Type: 'Timer'`,
  `TriggerName: 'reconcileTablePaymentsTimer'`.
- Query only a bounded batch of stale schema-v2 awaiting/unpaid or uncertain
  orders. Use signed
  `/v3/pay/partner/transactions/out-trade-no/{out_trade_no}` requests with
  `sp_mchid` and the order's snapshotted `sub_mchid`.
- Only verified `trade_state === 'SUCCESS'` calls the shared success
  transition. Other states/errors never create local success.

For either source, require exact matches for:

- `sp_appid`, optional/required `sub_appid`, `sp_mchid`, `sub_mchid`;
- `out_trade_no`, `trade_type === 'JSAPI'`, `trade_state === 'SUCCESS'`;
- bound payer OPENID in the correct payer field;
- non-empty `transaction_id`, parseable official `success_time`;
- CNY and the amount invariants above.

## One idempotent success transition

Within one database transaction:

- Re-read and validate the exact order, immutable payment-profile snapshot,
  session, and token-free business relationships. Never trust caller-supplied
  shop/order amounts or require a mutable current profile to remain enabled.
- Use a deterministic `payment_succeeded` financial-event document ID. Create
  the append-only event once; a notification/query race or replay validates the
  existing immutable snapshot and performs no duplicate write.
- Set the order to `paymentStatus='paid'`, `orderStatus='complete'`, and
  `splitStatus='pending'`; store the verified transaction ID, official payment
  time, amount split, and recomputed 5% snapshot.
- Close only the matching schema-v2 session and remove only the occupancy whose
  shop/store/table/session identity matches the order. Never remove an
  unrelated newer occupancy.
- A verified duplicate is successful and side-effect free. A signed
  merchant/AppID/payer/currency/order/amount mismatch writes no success event,
  never closes/releases the table, and durably places the identifiable order
  in `manual_review` with one deterministic redacted mismatch event. Unsigned,
  stale, malformed, or unknown-order input writes nothing.
- Local `wx.requestPayment` results are not an input to this transition.

## Mini-program page

- Declare `pages/table-checkout/index` in `miniprogram/app.json`.
- Parse only the checkout token, load the public view, and call
  `createTablePayOrder({token})`.
- `wx.requestPayment` success, cancellation, and failure may only trigger
  bounded server-status polling. The page and service layer never mark an
  order paid or close a session locally.
- Clear timers on hide/unload and prevent double taps. Cloud-not-ready mode
  must fail closed; do not simulate a successful real payment in mock data.

## Required focused proof

At minimum, RED/GREEN tests must prove:

- 128-bit token privacy, malformed/collision lookup behavior, public-field
  allowlist, and authorized QR generation;
- exact ready-profile checks, context AppID binding, first-payer binding,
  same-payer idempotency, another-payer rejection, and create/external race;
- exact APIv3 body and exact five-field client response;
- forged/stale/malformed notification rejection before writes;
- every merchant/AppID/order/payer/currency/amount mismatch is fail closed;
- `payer_total < total` produces a separate coupon subsidy and commission only
  on `payer_total`;
- duplicate callback and notification/query race create exactly one financial
  event and one terminal transition;
- neither local request-payment success nor non-success query state releases a
  table;
- verified success closes only the matching session/occupancy;
- timer guard, deployable-copy byte parity, and page polling/timer cleanup.

## External acceptance boundary

Focused tests must use injected transport/fixtures only. Real payment cannot be
claimed accepted until service-provider credentials, a ready special merchant,
notification routing, a published mini-program version, and a real-funds
sandbox/pilot transaction have been validated outside this local task.
