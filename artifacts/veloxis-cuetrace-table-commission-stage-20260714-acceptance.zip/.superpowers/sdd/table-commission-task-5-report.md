# Task 5A Report — Checkout Token, Public Quote, and QR Capability

## Frozen scope

This report covers only the root-authorized Task 5A slice:

- issue a canonical 128-bit checkout token when a schema-v2 table order is first created;
- persist only its lowercase SHA-256 digest and never reveal or rotate it on an idempotent order retry;
- expose the bearer-token public quote through `getTableCheckoutOrder` with a strict field allowlist;
- generate an owner-only fixed mini-program code and support only an explicit safe token rotation;
- prevent owner-side external settlement after any platform-payment claim or attempt;
- provide byte-identical deployable token helpers and focused proof.

Payment creation, notifications, payment reconciliation, the customer page, refunds,
profit sharing, bill reconciliation, deployment, and real-funds acceptance are outside
this frozen Task 5A slice. The overall Task 5 and project are not declared complete.

## TDD evidence

The following meaningful RED states were observed before their production behavior
was implemented:

1. `tests/tableCheckoutToken.test.js` exited 1 with `MODULE_NOT_FOUND` for the
   missing canonical `cloudfunctions/_shared/table-payment/checkout-token` module.
2. After adding the pure token module and deployed copies, the test exited 1 because
   `createTableOrder` returned no 22-character `checkoutToken`.
3. After the order-token behavior became green, the test exited 1 with
   `MODULE_NOT_FOUND` for the approved `getTableCheckoutOrder/index.js` name.
4. After the public read became green, the test exited 1 with `MODULE_NOT_FOUND`
   for `genTableCheckoutCode/index.js`.
5. After QR generation and safe rotation became green, the test exited 1 because
   `markTableOrderExternalPaid` still returned `ok:true` for an order carrying a
   platform-payment marker.
6. The affected Task 3 regression then exited 1 because its exact quote contract
   did not yet include the new immutable `quotedTableFeeFen`; the regression was
   updated only for Task 5A fields and token privacy.

Every RED was followed by the minimum corresponding production change and a focused
GREEN rerun.

## Current GREEN evidence

Bundled Node runtime:

`C:\Users\15384\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe`

- `node tests/tableCheckoutToken.test.js` — exit 0,
  `table checkout token ok (6 tests)` after independent-review remediation.
- `node tests/tableSessionOrderFlow.test.js` — exit 0, all 10 Task 3 behavior
  groups passed, including trusted checkout and external settlement.
- `node tests/cloudSharedParity.test.js` — exit 0,
  `cloud shared parity ok (8 explicit copies)`; its fixed allowlist now includes
  the five pre-existing finance copies and the three approved checkout-token copies.
- `node --check` — exit 0 for 12 Task 5A-related JavaScript files present at the
  time of verification, including the three temporarily retained misnamed files.
- `ConvertFrom-Json` — exit 0 for the three new package manifests present at the
  time of verification, including the temporarily retained misnamed manifest.

## Independent-review remediation

The Task 5A independent review found two Important issues, both remediated with a
focused RED before the production/script change:

1. A one-millisecond session priced at one fen per hour rounded to a zero-fen quote,
   yet `createTableOrder` returned `ok:true`, created an unusable order, and moved the
   session to `awaiting_payment`. The new regression first failed with `true !== false`.
   The root cause was the pre-write validation accepting every non-null rounded result;
   it now also rejects `tableGrossFen <= 0` before any order/session/occupancy write.
   The regression proves the complete state and write count remain unchanged.
2. The focused token test byte-compared deployed copies, but the canonical token
   helper and its three approved destinations were absent from the explicit sync
   allowlist. The parity test first failed with a 5-entry actual versus 8-entry expected
   allowlist. The script now guards `_shared/table-payment` with the same repository,
   ancestor, leaf-type, and reparse-point checks, and contains only the three literal
   approved destinations; the misnamed directory is not referenced.

Fresh remediation verification:

- checkout-token test: 6/6 passed;
- Task 3 regression: all 10 behavior groups passed;
- parity plus Windows PowerShell AST assertion: 8 explicit copies passed;
- `node --check`: the three remediation-touched JavaScript files passed.

Per the brief, `scripts/codex-verify.ps1`, the full test suite, Git staging,
commits, deployment, credentials, network calls, and real payments were not run.

## Behavior frozen for independent review

- Tokens are generated from exactly 16 cryptographically random bytes and encoded
  as 22-character unpadded base64url text.
- Validation decodes exactly 16 bytes and re-encodes to the identical text, rejecting
  regex-compatible non-canonical lookalikes before database access.
- `createTableOrder` stores only `checkoutTokenHash`, sets immutable
  `quotedTableFeeFen`, returns plaintext only alongside the first successful create,
  and never returns or rotates it on an idempotent retry.
- Public lookup hashes the bearer token, queries at most two matching schema-v2
  orders, and returns the same generic not-found result for zero or multiple matches.
- The public response contains exactly store/table display names, start/checkout
  time, billed duration, snapshotted hourly price, gross/discount/quote amounts,
  order/payment status, and derived `canPay`; it excludes ownership, payer, merchant,
  transaction, token hash, settlement, and credential data.
- QR generation is shop-owner authenticated, fixes the page and code parameters
  server-side, embeds only `t=<token>`, bounds the PNG to 1 MiB in memory, and returns
  base64 PNG data without a plaintext token field.
- Explicit `{orderId, rotate:true}` rotation is transactional and is allowed only
  while the order is awaiting/unpaid, payer-unbound, and has no payment claim,
  attempt, profile snapshot, prepay, or uncertain marker.
- External settlement returns `PLATFORM_PAYMENT_STARTED` without changing order,
  session, or occupancy if any canonical platform-payment marker is present.

## Files changed for Task 5A

- `tests/tableCheckoutToken.test.js`
- `tests/tableSessionOrderFlow.test.js`
- `cloudfunctions/_shared/table-payment/checkout-token.js`
- `cloudfunctions/createTableOrder/index.js`
- `cloudfunctions/createTableOrder/lib/checkout-token.js`
- `cloudfunctions/genTableCheckoutCode/index.js`
- `cloudfunctions/genTableCheckoutCode/package.json`
- `cloudfunctions/genTableCheckoutCode/lib/checkout-token.js`
- `cloudfunctions/getTableCheckoutOrder/index.js`
- `cloudfunctions/getTableCheckoutOrder/package.json`
- `cloudfunctions/getTableCheckoutOrder/lib/checkout-token.js`
- `cloudfunctions/markTableOrderExternalPaid/index.js`
- `scripts/sync-table-finance-libs.ps1`
- `tests/cloudSharedParity.test.js`
- `.superpowers/sdd/table-commission-task-5-report.md`

## Pending authorized cleanup

An interim root instruction briefly named the public function `getPublicTableOrder`.
Three files were created under that name immediately before the root corrected the
contract back to the approved `getTableCheckoutOrder` name:

- `cloudfunctions/getPublicTableOrder/index.js`
- `cloudfunctions/getPublicTableOrder/package.json`
- `cloudfunctions/getPublicTableOrder/lib/checkout-token.js`

The project requires explicit Zhang approval before deleting any file. These files
have therefore been left untouched after the correction and are not part of the
frozen implementation contract. Root has requested deletion authorization; cleanup
and a fresh syntax/package count remain pending that approval.

## Assumptions and residual acceptance boundary

- Task 5B will use the coordinated canonical markers
  `paymentClaim:{attemptId,status,claimedAt,leaseExpiresAt}`, `payerOpenid`,
  `paymentProfileSnapshot`, `prepayId`, and `prepayExpiresAt`; null/empty idle values
  do not block external settlement or safe rotation, while any populated value does.
- Mini-program code generation is tested only with an injected in-memory CloudBase
  OpenAPI fixture. A published `pages/table-checkout/index` route and real CloudBase
  OpenAPI behavior remain external acceptance work.
- Random-token collision is fail-closed at lookup through the two-row query. Tests
  do not replace production collection/index configuration or live concurrency tests.
- No local test can establish service-provider credentials, special-merchant
  readiness, callback routing, mini-program publication, or real-funds acceptance.
  Those remain outside this Task 5A slice and require Zhang-approved external testing.

## Freeze status

Task 5A business behavior and independent-review remediation are frozen for root
re-review. Only removal of the three explicitly listed misnamed files (after Zhang
approval) and fixes for findings directly caused by this Task 5A slice are authorized;
no further feature expansion is included here.
