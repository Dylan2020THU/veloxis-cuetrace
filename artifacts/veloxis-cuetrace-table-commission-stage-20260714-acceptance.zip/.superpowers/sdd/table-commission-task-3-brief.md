## Task 3: Trusted Table Configuration, Sessions, and Checkout Orders

### Files

- Create/modify exactly the Task 3 files listed in `docs/superpowers/plans/2026-07-14-table-commission-billing-implementation.md`.
- Create report: `.superpowers/sdd/table-commission-task-3-report.md`.

### Binding contracts

#### Store table configuration

- `saveShopStore` remains owner-only through the existing bound-account + approved `shop` role checks.
- Normalize every persisted `tableTypes` entry to:

```js
{
  tableId,
  name,
  pricePerHourFen,
  pricePerHour,
  image,
  bgColor,
  pricingRuleVersion: 'hourly_exact_v1'
}
```

- `pricePerHourFen` is a positive safe integer. Parse owner-entered yuan to integer fen without retaining fractional fen; `pricePerHour` is the normalized display value `pricePerHourFen / 100`.
- Preserve a non-empty existing `tableId`. When a submitted legacy/brand-new entry lacks one, reuse the matching persisted entry's ID when safely identifiable; otherwise generate a collision-resistant 20-character lowercase-hex ID once. Reject duplicate IDs, missing names, and invalid/non-positive prices instead of silently saving unusable tables.
- Editing a table in `table-types/index.js` or `brand-add/index.js` must retain its existing `tableId`; saved normalized data returned by the cloud function may refresh the page state.

#### Identity and scope

- New financial sessions, orders, and external-paid actions are owner-only in this first release because no manager ACL exists. Verify the deterministic WeChat binding, active account, bound user, approved `shop` role, store ownership, and record `shopId === OPENID`. Never trust a client owner/shop ID.
- Different owners must not read or mutate each other's version-2 sessions/orders/occupancy.
- Repository is unborn. Do not initialize/stage/commit/write Git and do not delete files. Do not read or modify `.agents/**`.

#### Session and occupancy

- Use collection `table_occupancies` and deterministic document ID `${storeId}__${tableId}`. Open the session and claim this guard in one `db.runTransaction`; a live guard makes the second same-table open return `{ok:false, code:'TABLE_OCCUPIED'}`. Transaction failure must leave neither record.
- `createSession` accepts only `storeId`, `tableId`, optional `memberOpenid`, `coachOpenid`, `coachJoinedAt`, and `verified`. It reads the exact server-side table and saves its immutable snapshot; it never accepts a client price.
- Version-2 session fields must include:

```js
{
  schemaVersion: 2,
  _openid: OPENID,
  shopId: OPENID,
  storeId,
  tableId,
  pricingSnapshot: {
    tableId,
    name,
    pricePerHourFen,
    pricePerHour,
    pricingRuleVersion: 'hourly_exact_v1',
    minimumDurationMs: 0,
    billingStepMs: 1,
    roundingMode: 'nearest_fen'
  },
  status: 'active',
  startedAt, checkoutAt: null, closedAt: null, orderId: '',
  openedBy: OPENID, checkoutBy: '',
  memberOpenid, coachOpenid, coachJoinedAt, verified,
  createdAt, updatedAt
}
```

- Business times used for arithmetic (`startedAt`, later `checkoutAt/closedAt`) are server-runtime millisecond timestamps, never client values; audit `createdAt/updatedAt` use `db.serverDate()`.
- `getSessions` continues to return the owner's historical records plus version-2 records; no cross-owner leakage.

#### Trusted checkout order

- `createTableOrder` accepts an event whose only business input is non-empty `sessionId`.
- If `sessionId` is missing, or any retired finance field is supplied (`amount`, `durationMin`, `storeId`, `tableId`, `tableName`, any price/rate/cost/net field), return `{ok:false, code:'VERSION_RETIRED'}` before writes. Reject other unsupported business keys with `INVALID_INPUT`.
- Verify the bound shop owner and session ownership. In one transaction: read the session, reuse an existing deterministic order if present, otherwise require `status='active'`, freeze `checkoutAt=Date.now()`, validate `startedAt`, calculate:

```js
elapsedMs = Math.max(0, checkoutAt - startedAt)
tableGrossFen = Math.round(elapsedMs * pricePerHourFen / 3600000)
tableDiscountFen = 0
paidTableFeeFen = tableGrossFen
totalCostFen = round(paidTableFeeFen * 500 / 10000)
shopNetFen = paidTableFeeFen - totalCostFen
```

- Keep the occupancy guard while awaiting payment. Atomically create `shop_orders/{orderIdForSession(sessionId)}` and move session `active -> awaiting_payment` with `orderId` and `checkoutBy`.
- The new order must include at least these exact values/fields:

```js
{
  schemaVersion: 2,
  _openid: OPENID, shopId: OPENID, storeId, tableId, sessionId,
  payerOpenid: '',
  orderId, outTradeNo, splitNo,
  tableName,
  pricingSnapshot,
  startedAt, checkoutAt,
  actualDurationMs: elapsedMs,
  billedDurationMs: elapsedMs,
  tableGrossFen, tableDiscountFen: 0, paidTableFeeFen,
  billingMode: 'table_commission', commissionRateBps: 500,
  includesChannelFee: true, policyVersion: 'table_commission_v1',
  splitCycle: 'T_PLUS_1',
  totalCostFen, channelFeeFen: null, platformNetFen: null, shopNetFen,
  wechatTransactionId: '', paidAt: null,
  splitStatus: 'pending', splitCompletedAt: null,
  refundedTableFeeFen: 0, reversedTotalCostFen: 0,
  orderStatus: 'awaiting_payment', paymentStatus: 'unpaid',
  createdAt, updatedAt
}
```

- Return a server quote containing `orderId`, `sessionId`, `paidTableFeeFen`, `tableGrossFen`, `tableDiscountFen`, `actualDurationMs`, `pricePerHourFen`, and the three state fields. Repeated checkout must return the same stored order/quote without recomputing time or duplicating writes.
- `cloudfunctions/createSession/lib/{money,state}.js` and `cloudfunctions/createTableOrder/lib/{money,state}.js` must be exact deployable copies of the Task 1 shared finance modules. Use the copied helpers for settlement and deterministic IDs.

#### Retired direct close and external paid

- `closeSession` is a compatibility endpoint that performs no DB access and returns `{ok:false, code:'PRODUCT_RETIRED'}`.
- Add `markTableOrderExternalPaid({orderId, reason})`. `reason` must be a non-empty trimmed string (maximum 200 characters). Only the owning bound shop user may act.
- In one transaction, require a version-2 awaiting-payment order and its session, then set:

```js
orderStatus: 'external_paid',
paymentStatus: 'not_applicable',
splitStatus: 'not_applicable',
totalCostFen: 0,
channelFeeFen: 0,
platformNetFen: 0,
shopNetFen: paidTableFeeFen,
externalPaidReason,
externalPaidBy: OPENID,
externalPaidAt,
updatedAt
```

- Close the same session (`status:'closed'`, `closedAt`, `updatedAt`) and release only its matching occupancy guard. Do not create WeChat-payment, split, verified-training, or automatic-commission records.
- A repeated call for an already `external_paid` order is idempotent and returns the existing outcome; paid/complete/canceled/foreign orders are rejected.

#### Client service behavior

- Preserve public service names needed by existing callers. `createSession`, `closeSession`, trusted checkout (`addTableOrder` or an added alias), and `markTableOrderExternalPaid` must use `callCheckedCloud` for real mutations.
- No cloud-unavailable path may write a local successful session/order/external-paid financial state. Reject with `CLOUD_NOT_READY`. Existing demo-only read/display data may remain, clearly separate from real mutation helpers.
- The Hall page itself is migrated in Task 7; do not edit it in Task 3.

### Required TDD coverage

Write `tests/tableSessionOrderFlow.test.js` first and capture RED. It must behaviorally cover:

- stable/unique table IDs, integer-fen normalization, edit preservation, invalid config rejection, and cross-owner store update rejection;
- unbound/non-shop/cross-owner session rejection;
- immutable pricing snapshot and ignored/disallowed client pricing;
- same-table concurrency and rollback on either session or occupancy write failure;
- version-2 owner-only reads;
- legacy checkout inputs/missing session rejection;
- exact-millisecond server pricing, all required order snapshot fields, `active -> awaiting_payment`, retained occupancy, deterministic ID safety, repeat checkout idempotency, and transaction rollback;
- direct close retirement with zero writes;
- required external reason, owner-only action, zero automatic cost, correct state transitions, session close, matching occupancy release, no extra benefits/events, idempotency, and rollback;
- client finance mutations call checked cloud and fail closed without local writes when cloud is unavailable;
- both deployable finance-lib copies match the shared sources byte-for-byte.

Use a transaction-capable CloudBase fake that commits atomically and can inject write failure. Run:

```powershell
& 'C:\Users\15384\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe' tests\tableSessionOrderFlow.test.js
```

Then run `node --check` with the bundled runtime for every changed/new JavaScript file. Do not run the full verifier; root does that only at final completion.

### Report contract

Write `.superpowers/sdd/table-commission-task-3-report.md` containing status, exact RED evidence, files changed, exact GREEN/syntax results, assumptions, self-review of authorization/transactions/idempotency/amount units, and confirmations of no Git write/no file deletion/no `.agents` access.
