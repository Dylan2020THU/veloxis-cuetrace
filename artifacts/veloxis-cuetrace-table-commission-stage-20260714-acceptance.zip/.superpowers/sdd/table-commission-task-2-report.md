# Task 2 Report: Retire New Legacy Charges and Coach Commission

## Status

`DONE`

## RED evidence

### Legacy billing retirement

Command:

```powershell
& 'C:\Users\15384\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe' tests\legacyBillingRetirement.test.js
```

- Exit code: `1`
- Expected failure: `testFreeBillingCompatibility` received `false` from `canUse('shop.report')` while the retirement contract requires `true` (`false !== true`, line 48). This proved the old shop paywall behavior was still active before production changes.

### Coach commission retirement

Command:

```powershell
& 'C:\Users\15384\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe' tests\coachCommissionRetirement.test.js
```

- Exit code: `1`
- Expected failure: `testCompatibilityCommissionMathIsZero` received `0.05` from `COACH_COMMISSION_RATE` while the retirement contract requires `0` (`0.05 !== 0`, line 151). This proved the former commission behavior was still active before production changes.

## Files changed and behavior summary

### Tests

- Created `tests/legacyBillingRetirement.test.js`: behaviorally covers free shop access, compatibility billing APIs, fail-closed client helpers without mutation, all five fail-closed cloud endpoints without writes/network, no recurring trigger, no active paywall/shop UI, and retained cancellation/callback files.
- Created `tests/coachCommissionRetirement.test.js`: covers cloud and mock booking omission of `commissionRate`, zero unsettled commission/net=gross, zero-commission settlement snapshots, authoritative historical settled snapshots, zero coach amount for table verification, and retired UI/legal copy.
- Rewrote `tests/shopSubscriptionPlans.test.js` and `tests/recurringCloudFunctions.test.js` around retired-product compatibility behavior.
- Minimally migrated `tests/recurringSubscriptionGuard.test.js`: the original plan excluded this test, but its active-signing expectations directly contradicted the required `PRODUCT_RETIRED` endpoint. After explicit root-task authorization, the active create-contract cases were replaced by one zero-write/zero-network retirement test; callback, cancellation, and `deleteAccount` guard semantics were retained unchanged.

### Billing and client compatibility

- `miniprogram/utils/billing.js`: `canUse`, `hasPlan`, `isPlanActive`, and `requirePlan` always allow; plan/purchase option lists are empty; coach commission compatibility exports evaluate to zero.
- `miniprogram/services/data.js`: `upgradePlan`, `createPayOrder`, `createVirtualPayOrder`, and `createRecurringContract` return `{ ok: false, code: 'PRODUCT_RETIRED' }` without cloud or local mutation. Mock booking data omits `commissionRate`; table-session verification writes coach amount `0`; unsettled settlement math is zero-commission; historical settled totals use saved `netAmount` snapshots.
- `miniprogram/components/paywall/index.js` and `miniprogram/app.js`: compatibility entry points immediately allow without mounting or exposing payment behavior.
- `miniprogram/app.json`: removed the delegated-signing mini-program allow-list entry.

### Cloud endpoints and trigger

- `cloudfunctions/upgradePlan/index.js`
- `cloudfunctions/createPayOrder/index.js`
- `cloudfunctions/createVirtualPayOrder/index.js`
- `cloudfunctions/createRecurringContract/index.js`
- `cloudfunctions/createRecurringDebit/index.js`

Each compatibility endpoint now returns `{ ok: false, code: 'PRODUCT_RETIRED' }` as its complete handler, before any database write or payment/network call.

- `cloudfunctions/createRecurringDebit/config.json`: retained with an empty `triggers` array.

### Coach booking, settlement, and verification

- `cloudfunctions/createBooking/index.js`: new coach bookings omit `commissionRate`.
- `cloudfunctions/getShopCoachSettlement/index.js`: pending commission is `0`, pending net equals gross, and displayed historical settled totals sum authoritative `coach_settlements.netAmount` snapshots.
- `cloudfunctions/getCoachSettlementDetail/index.js`: pending commission is `0` and net equals gross.
- `cloudfunctions/settleCoach/index.js`: new settlement snapshots use `commission: 0` and `netAmount: gross` without rewriting existing settlements.
- `cloudfunctions/recordVerifiedTraining/index.js`: table-session verification always persists coach lesson `amount: 0`.

### UI and legal copy

- Removed retired subscription/paywall hooks and copy from `miniprogram/pages/shop/dashboard/index.js`, `miniprogram/pages/shop/dashboard/index.wxml`, `miniprogram/pages/profile/index.js`, `miniprogram/pages/profile/index.wxml`, and `miniprogram/pages/shop/brand-add/index.js`.
- Removed former coach commission/service-fee presentation from `miniprogram/pages/coach/bookings/index.js`, `miniprogram/pages/coach/bookings/index.wxml`, and `miniprogram/pages/shop/coach-settlement/index.wxml`.
- Updated only directly affected payment/membership/commission wording in `miniprogram/pages/legal/index.js`; unrelated legal/privacy text was preserved.

## GREEN / focused verification

All commands used the bundled runtime and exited `0` in the final fresh run:

```powershell
& 'C:\Users\15384\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe' tests\legacyBillingRetirement.test.js
& 'C:\Users\15384\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe' tests\coachCommissionRetirement.test.js
& 'C:\Users\15384\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe' tests\shopSubscriptionPlans.test.js
& 'C:\Users\15384\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe' tests\recurringCloudFunctions.test.js
& 'C:\Users\15384\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe' tests\recurringSubscriptionGuard.test.js
& 'C:\Users\15384\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe' tests\accountDeletionGracePeriod.test.js
```

Summary: `6/6 PASS`, `0` failed.

## Syntax checks

Ran the following command form with the bundled runtime for every Task 2 JavaScript file changed:

```powershell
& 'C:\Users\15384\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe' --check '<file>'
```

Checked 24 files: the five changed test files, `miniprogram/utils/billing.js`, paywall/app/shop/profile/brand/data/coach/legal JavaScript files, the five retired cloud endpoints, and the five coach cloud functions. Summary: `24/24 PASS`, all exit code `0`.

## Self-review

- Every active client purchase helper returns `PRODUCT_RETIRED` before reading/mutating local entitlement state or calling a cloud function.
- All five active charge/sign/debit cloud endpoints consist only of the retired-product response, so they cannot reach database writes, CloudPay, HTTPS, signing, or debit logic.
- The global paywall compatibility entry returns `true` immediately; the component stays hidden and contains no executable purchase/signing branch or `FORCE_VIRTUAL_PAY_FOR_TEST`.
- Recurring cancellation and historical callback files remain present and were not modified; the debit timer has no active trigger.
- New and currently unsettled coach business uses zero commission and `net = gross` in overview, detail, mock behavior, and new settlement creation.
- Historical settled snapshots are preserved: overview totals read stored `coach_settlements.netAmount`, and tests retain a historical `commission: 50` / `netAmount: 150` record unchanged while creating a new zero-commission snapshot.
- Table-session verified training records coach revenue as `amount: 0` in cloud and mock paths.
- The recurring guard plan contradiction was resolved only within the explicitly authorized test scope; callback, cancellation, and account-deletion history guards remain green.
- No `.agents/**` file was read or modified.
- No Git repository initialization, staging, commit, reset, checkout, or other Git write occurred.
- No file was deleted.
