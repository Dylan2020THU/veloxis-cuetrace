# Task 6 Brief — T+1 Profit Sharing and Refunds

## Objective

Implement the approved Task 6 profit-sharing and refund lifecycle with focused
TDD. No money movement may be inferred from an accepted HTTP request: signed
query results are authoritative, and every unknown or conflicting state fails
closed into `manual_review`.

This task must not delete files, edit `.agents/**`, deploy, use real merchant
credentials, call the network in tests, run the full verifier, or use Git.

## Sequencing gate

- Automatic splitting is eligible only after Task 7-style official trade-bill
  evidence has populated a non-negative safe-integer `channelFeeFen`, a
  non-negative `platformNetFen`, a stable evidence hash, and
  `financeAutomationBlocked !== true`.
- Implementing Task 6 before the bill importer is allowed only with injected
  confirmed fixtures. Production orders without that evidence remain pending;
  never estimate the channel fee.
- `channelFeeFen > totalCostFen` is `manual_review`; the platform absorbs the
  excess and no split is attempted.

## Required adapter completion

Extend the reviewed APIv3 adapter and its tests before workflow code:

- `GET /v3/profitsharing/orders/{out_order_no}` with exact query
  `sub_mchid` and `transaction_id`;
- `GET /v3/profitsharing/return-orders/{out_return_no}` with exact query
  `sub_mchid` and `out_order_no`;
- `GET /v3/refund/domestic/refunds/{out_refund_no}` with `sub_mchid`;
- retain existing add-receiver, split, split-return, unfreeze and refund calls.

For encrypted receiver `name`, select one exact trusted encryption key ID and
send the same value as `Wechatpay-Serial`. Add
`WXPAY_ENCRYPTION_KEY_ID` as an optional exact key into the already trusted
`WXPAY_PLATFORM_CERTS_JSON` map. If omitted, use the configured public-key ID;
otherwise allow a sole trusted certificate only. Multiple certificate entries
without an explicit selection fail closed. Encrypt with RSAES-OAEP through the
reviewed adapter. Never persist or log the plaintext receiver name.

## TDD order

1. Add RED adapter tests for all three query endpoints and encryption-key/header
   binding, then make only those tests green.
2. Add RED settlement tests for eligibility, claims, receiver relation, exact
   split, query-to-terminal and unfreeze.
3. Add RED refund tests for authorization, cumulative bounds, pre/post-split
   ordering, query/notification idempotency and cumulative recomputation.
4. Add deployable copies, sync/parity coverage, focused regressions and syntax
   checks. Freeze for independent review.

## Settlement eligibility and claim

`settleTableProfitSharing` is timer/internal-only. Reject any invocation with an
`OPENID`; require exact `Type: 'Timer'` and
`TriggerName: 'settleTableProfitSharingTimer'`. Process a bounded stale batch.

An order is eligible only when all immutable payment snapshot fields are valid,
`paymentStatus === 'paid'`, `orderStatus === 'complete'`,
`splitStatus` is pending/retryable, verified payment and official channel-fee
evidence exist, no refund is pending, and automation is not blocked. Claim one
attempt/lease transactionally; never hold a transaction over a network call.
Only the same attempt may finalize.

## Receiver and exact split

- Receiver type/account are exactly `MERCHANT_ID` and the configured service
  provider merchant ID from the order payment snapshot.
- Add the relation for the special merchant using the exact snapshot AppID,
  optional sub-AppID, sub-merchant ID, configured encrypted legal name, and the
  approved relation type. Treat a verified already-exists relation as
  idempotent; other ambiguous results require query/retry or manual review.
- Split request uses exact transaction ID, deterministic `splitNo`, special
  merchant ID, `unfreeze_unsplit: false`, and one receiver whose amount equals
  the confirmed positive `platformNetFen`. Description is fixed server-side.
- If `platformNetFen === 0`, do not create a zero receiver; proceed only to the
  verified unfreeze path.
- An accepted split response is not terminal. Query the deterministic split
  order until `state === 'FINISHED'`, then require the one expected receiver to
  have exact type/account/amount and successful terminal result. Any closed,
  duplicate, missing or mismatched receiver is `manual_review`.
- Unfreeze only after the expected split terminal result (or the reconciled
  zero-split branch). Query/validate the verified unfreeze result before setting
  `splitStatus === 'succeeded'` and appending one deterministic event.

## Refund command and cumulative math

`requestTableRefund({orderId, refundFen, reason, idempotencyKey})` is owner-only.
It accepts exactly those fields, requires a positive safe-integer gross refund,
a bounded non-empty reason and canonical idempotency key, and snapshots a
deterministic refund number. Do not accept shop, merchant, payer, total or
transaction fields from the client.

- Cumulative requested gross refund must not exceed `wechatOrderTotalFen`.
- Cumulative verified payer refund must not exceed `wechatPayerTotalFen`.
- Remote refund identity must match snapshot `sp_mchid`, `sub_mchid`,
  transaction/out-trade number and both CNY totals. Validate remote
  `amount.total === wechatOrderTotalFen`; never confuse coupon subsidy with
  payer cash.
- Recompute the 500-bps total cost from cumulative final retained verified payer
  cash, not by summing rounded per-refund deltas. Full verified payer refund sets
  retained paid table fee and total cost to zero.

For an order not yet split, claim and submit the refund directly. For a completed
split, first determine and complete the required deterministic split return,
query it to terminal `SUCCESS`, and only then submit the WeChat refund. Never use
the unsafe refund-first sequence. A processing/failed/unknown return blocks the
refund and sets `manual_review` when recovery is not deterministic.

The split-return amount is derived from cumulative snapshots, capped by the
remaining amount actually split to the service provider, and must make a full
refund return all remaining platform split. Record provisional adjustment
separately; final channel-fee/refund-fee evidence is reconciled later and may
require manual adjustment. Never create a zero/negative return request.

## Refund terminal truth

- A successful refund request is not final. Persist `processing`, then use the
  signed refund notification and the signed query-by-out-refund-number endpoint.
- `tableRefundNotifyV3` verifies fresh signature over untouched raw bytes before
  parsing, requires the exact refund-success outer event/resource contract,
  decrypts with fatal UTF-8, and calls the same transition as query recovery.
- Validate exact refund number, transaction/order identity, currency, requested
  totals, and official payer-refund amount. Unknown or malformed unsigned input
  writes nothing. Identifiable signed mismatches create one redacted deterministic
  mismatch event and `manual_review` without changing financial success state.
- Notification/query races create exactly one immutable refund-success event and
  one cumulative order update. Duplicate verified terminal input is side-effect
  free.
- Pre-existing or multiple refunds use deterministic documents and claims. A
  stale processing claim is queried before retry; no second remote refund number
  may be invented for the same idempotency key.

## Financial snapshots after verified refund

Persist both gross/coupon and payer-cash refund facts. Recompute:

- retained payer cash = original `wechatPayerTotalFen` minus cumulative verified
  payer refunds;
- `paidTableFeeFen` = retained payer cash;
- `totalCostFen` and `shopNetFen` from retained payer cash under 500 bps;
- coupon subsidy separately from verified WeChat amounts;
- `shopSettlementFen = shopNetFen + retained coupon subsidy`.

Do not finalize a new `channelFeeFen` or `platformNetFen` from assumptions. Mark
the order as awaiting official refund-fee reconciliation; Task 7 bill evidence
will confirm the negative fee rows. Full refund must still snapshot zero total
cost immediately.

## Deployability and focused proof

- Each new cloud function must contain byte-identical local copies of every
  required `wechatpay-v3`, `table-finance`, and Task 6 pure helper. No deployed
  function imports a parent `_shared` path.
- Extend the literal allowlist sync script and parity tests. It accepts no paths,
  rejects path escapes and all ancestor reparse points, and never deletes files.
- Focused tests must prove timer/owner guards, actual-fee gate, fee-over-cost
  review, exact encrypted receiver/header, terminal query validation, zero split,
  idempotent retries, unfreeze ordering, refund-before/after-split ordering,
  cumulative partial/multiple/full refunds, coupon-aware payer totals, upper
  bounds, split return, forged callback rejection, race idempotency and fail-closed
  unknown states.

Real split/refund acceptance remains external until approved service-provider and
special-merchant accounts, authorization, keys, callback routes, next-day bills
and a small real-funds payment/split/partial-refund/full-refund cycle are tested.
