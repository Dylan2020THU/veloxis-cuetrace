# Task 3 Report: Trusted Table Configuration, Sessions, and Checkout Orders

## Status

The fourth-cycle local Task 3 implementation is GREEN. The latest root review reported zero Critical and three Important findings; all three now have failing-first regressions and minimum fixes, with root re-review left to the root task. The focused behavior test passes all ten groups, and all five JavaScript files directly changed in the fourth cycle pass the bundled Node syntax check. No cloud deployment or real CloudBase data migration was performed in this task.

## TDD Evidence

The behavior test was created before production edits:

- Test file: tests/tableSessionOrderFlow.test.js
- Runtime: C:\Users\15384\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe
- Command: node.exe tests\tableSessionOrderFlow.test.js

The first harness run exposed an unsafe dereference as a TypeError, so it was not accepted as the required RED. The assertion was corrected without changing production code and rerun.

Accepted RED evidence:

- Exit code: 1
- Failure: AssertionError [ERR_ASSERTION]: saveShopStore should return normalized tableTypes
- Location: tests/tableSessionOrderFlow.test.js:315
- Reason: the pre-change saveShopStore returned no normalized tableTypes and persisted the submitted table configuration unchanged.

Production edits began only after that behavior failure was observed.

The first independent review then identified one CloudBase compatibility Critical and four Important edge cases. Regression coverage for all five was added before their fixes. The accepted second RED was:

- Exit code: 1
- Failure: AssertionError [ERR_ASSERTION]: missing store documents must be treated as not found instead of write failures
- Location: tests/tableSessionOrderFlow.test.js:385
- Reason: the real SDK defaults to throwing when doc.get targets a missing document, while the original fake always returned null.

The second test-first cycle added coverage for default missing-document throws, terminal-order checkout idempotency, checked store-save results, exact BigInt hourly rounding at the safe-integer boundary, and missing/mismatched occupancy guards. After the minimum fixes, the same focused suite returned exit code 0.

A subsequent root independent review found the client-controlled unknown store-ID create path, ambiguous occupancy-key components, and under-validated persisted idempotency states. Regression coverage was added before production changes. The accepted third RED was:

- Exit code: 1
- Failure: AssertionError [ERR_ASSERTION]: true !== false
- Location: tests/tableSessionOrderFlow.test.js:398
- Reason: saveShopStore still accepted an explicitly submitted tableId containing the reserved `__` sequence instead of returning INVALID_TABLE_CONFIG.

That cycle changed unknown client store IDs to update-only/zero-write denial, changed id-less creation to server `collection.add`, passed the returned store ID into the profile save, constrained store/table components, validated awaiting/external persisted order invariants, and expanded guard/idempotency coverage.

The third-cycle read-only reviewer then found a delimiter-boundary counterexample: `(a_, b)` and `(a, _b)` both produced `a___b`, plus an inverted persisted checkout timestamp and synchronized external-paid gross corruption that could still pass. Tests were added before the follow-up fixes. The accepted review-follow-up RED was:

- Exit code: 1
- Failure: AssertionError [ERR_ASSERTION]: false !== true
- Location: tests/tableSessionOrderFlow.test.js:637
- Reason: production still generated the old ambiguous occupancy document ID while the hardened fake required the new length-prefixed identity.

The follow-up uses a store-length-prefixed occupancy ID, rejects checkoutAt earlier than startedAt, and validates the complete trusted pricing/time/gross/policy state before both initial and repeated external-paid settlement.

The root final review then found three remaining Important fail-closed gaps. Fourth-cycle tests were added before production changes. The accepted fourth RED sequence was:

- First RED: exit code 1, `true !== false` at tests/tableSessionOrderFlow.test.js:885, proving a new order was written from an active session whose checkout/closed/order/audit fields were already populated.
- After that minimum fix, the next RED was exit code 1, `true !== false` at tests/tableSessionOrderFlow.test.js:1179, proving self-consistent but non-deterministic order/payment/split identifiers were accepted by external settlement.
- After the identifier/timestamp fix, the next RED was exit code 1, `Missing expected rejection` at tests/tableSessionOrderFlow.test.js:1372, proving local mock saveShopStore fulfilled an unknown client `_id` failure instead of rejecting it.

The fourth-cycle fixes require exact empty active-session checkout fields before new-order writes, reuse the byte-identical deployable state helper for deterministic orderId/outTradeNo/splitNo validation, reject unsafe or pre-checkout externalPaidAt values before writes, and reject unknown local-mock store IDs through the same Promise failure channel used by cloud mode.

Final focused GREEN evidence:

- Exit code: 0
- Passing groups:
  - store configuration is owned, stable, and normalized
  - table editors retain existing IDs
  - sessions enforce authorization, snapshots, concurrency, and rollback
  - version-two session reads are owner scoped
  - checkout is trusted, atomic, and idempotent
  - direct close is retired without database access
  - external paid is owner-only, atomic, and idempotent
  - client mock store creation uses generated IDs
  - client finance mutations fail closed and use checked cloud
  - deployable finance libraries match shared sources
- Final line: table session order flow ok

## Files Changed

Created:

- tests/tableSessionOrderFlow.test.js
- cloudfunctions/createSession/lib/money.js
- cloudfunctions/createSession/lib/state.js
- cloudfunctions/createTableOrder/lib/money.js
- cloudfunctions/createTableOrder/lib/state.js
- cloudfunctions/markTableOrderExternalPaid/lib/state.js
- cloudfunctions/markTableOrderExternalPaid/index.js
- cloudfunctions/markTableOrderExternalPaid/package.json
- .superpowers/sdd/table-commission-task-3-report.md

Modified:

- cloudfunctions/saveShopStore/index.js
- cloudfunctions/createSession/index.js
- cloudfunctions/getSessions/index.js
- cloudfunctions/closeSession/index.js
- cloudfunctions/createTableOrder/index.js
- miniprogram/pages/shop/table-types/index.js
- miniprogram/pages/shop/brand-add/index.js
- miniprogram/services/data.js

No Hall page file was modified.

## Syntax and Parity Evidence

Before the fourth cycle, the bundled Node runtime ran node --check on exactly these fourteen then-existing JavaScript files; every check reported SYNTAX=PASS and the summary reported SYNTAX_SUMMARY=PASS COUNT=14:

- tests/tableSessionOrderFlow.test.js
- cloudfunctions/saveShopStore/index.js
- cloudfunctions/createSession/index.js
- cloudfunctions/createSession/lib/money.js
- cloudfunctions/createSession/lib/state.js
- cloudfunctions/getSessions/index.js
- cloudfunctions/closeSession/index.js
- cloudfunctions/createTableOrder/index.js
- cloudfunctions/createTableOrder/lib/money.js
- cloudfunctions/createTableOrder/lib/state.js
- cloudfunctions/markTableOrderExternalPaid/index.js
- miniprogram/pages/shop/table-types/index.js
- miniprogram/pages/shop/brand-add/index.js
- miniprogram/services/data.js

The focused behavior test byte-compares both deployed money.js copies and all three deployed state.js copies against cloudfunctions/_shared/table-finance. All five comparisons pass. The new package.json is parsed as JSON by the same focused test.

Fourth-cycle fresh syntax evidence covers the five directly changed JavaScript files: tests/tableSessionOrderFlow.test.js, cloudfunctions/createTableOrder/index.js, cloudfunctions/markTableOrderExternalPaid/index.js, cloudfunctions/markTableOrderExternalPaid/lib/state.js, and miniprogram/services/data.js. The command returned exit code 0 with `syntax-ok 5`. The focused parity assertion now compares state.js in createSession, createTableOrder, and markTableOrderExternalPaid against the shared source; all three byte comparisons pass. Money.js remains deployed only to the two consumers that use it.

## Independent Review

The first read-only review reported With fixes. It found:

- default CloudBase missing-document throws were not represented by the fake;
- a stored terminal order was not reusable after its session closed;
- saveShopStore client failures could be treated as fulfilled success;
- Number multiplication could lose one fen at extreme safe inputs;
- a new awaiting-payment order did not verify its occupancy guard.

All five findings received focused regression coverage and minimum fixes. The same reviewer then re-read the changed test and implementation files and reported Ready, confirming every prior finding resolved and no new Critical or Important regression. The reviewer did not mutate files or rerun tests.

The later root independent review reported one Critical cluster and two Important findings: client-chosen unknown store IDs could race through a missing-doc `set`, occupancy components and the fake did not model delimiter/document-ID hazards, and the two stored-order idempotency exits did not fail closed on malformed persisted records. A strict third RED-to-GREEN cycle covered and fixed every item.

The third-cycle read-only reviewer initially reported no Critical and three Important counterexamples: underscore boundary ambiguity remained despite banning `__` inside components; an existing order could encode checkoutAt before startedAt with synchronized zero amounts; and external-paid retry could accept synchronized gross/paid corruption because its fixture and validator were incomplete. The reviewer supplied concrete counterexamples, all three received regression tests and minimum fixes, and the same reviewer re-read those exact fixes without mutating files. The final conclusion was Ready: all three Important findings were resolved, with no remaining Critical or Important issue. The reviewer did not run the full verifier.

That Ready result was superseded by the root final review, which reported zero Critical and three Important findings: incomplete initial active-session invariants, non-deterministic external order/payment/split identifiers plus an unchecked initial externalPaidAt, and a fulfilled local-mock unknown-store failure. The fourth strict RED-to-GREEN cycle above addresses all three; the root task owns the next independent re-review.

## Assumptions

- An approved shop owner is represented by the deterministic WeChat binding, an active matching account, the deterministic bound user, and a roles array containing shop, consistent with the existing account/store authorization contract.
- A missing tableId is reused from persisted configuration only when the trimmed table name maps to one unambiguous persisted non-empty ID. Otherwise a random ten-byte lowercase hexadecimal ID is generated.
- Store and table ID components are 1 to 64 ASCII characters from `[0-9A-Za-z_-]` and cannot contain `__`. Existing submitted IDs satisfying that contract remain stable; invalid persisted IDs are not reused.
- New stores omit `_id` and use the CloudBase `add` result as their server-generated ID. A supplied `_id` is update-only; missing or foreign records return STORE_NOT_OWNED without a store write.
- Occupancy document IDs prefix the store ID with its decimal length before the `__` delimiter. This keeps valid leading/trailing single underscores while making the pair mapping injective.
- Date.now in the server runtime is the trusted millisecond clock for startedAt, checkoutAt, closedAt, and externalPaidAt. Audit createdAt and updatedAt values use db.serverDate().
- CloudBase runTransaction provides conflict retry/atomic commit for the repository's existing document get, add, set, update, and remove APIs. Task 3 databases explicitly set throwOnNotFound to false where optional reads are required. The local fake defaults to real-SDK missing-document throws, reads that configuration, serializes transactions, and replaces live state only after a successful callback.
- When an occupancy guard does not match the order's session, external settlement closes the valid owned order/session but leaves the unrelated guard untouched. This implements “release only its matching occupancy guard.”
- Manager access was intentionally not inferred because no manager ACL exists. All new financial actions remain owner-only.
- The Hall checkout flow remains retired until its separately scoped Task 7 migration.

## Self-Review

### Authorization and scope

- saveShopStore verifies the deterministic binding, matching active account, deterministic bound user, approved shop role, and existing-store ownership before update.
- createSession performs the same identity checks and store ownership check inside the transaction. It writes _openid, shopId, and openedBy only from OPENID.
- getSessions requires the same owner identity, queries by _openid, and additionally filters version-two records whose shopId does not equal OPENID while retaining owned historical records.
- createTableOrder verifies owner identity, version-two session ownership, and store ownership inside the transaction. No client owner/shop identifier is accepted.
- markTableOrderExternalPaid verifies owner identity plus owned version-two order, session, and store records inside the transaction.

### Transactions and rollback

- createSession adds the session and sets the length-prefixed store/table occupancy guard within one transaction. Tests cover delimiter-boundary pairs and inject failure into either collection to prove live state is unchanged.
- createTableOrder deterministically sets the order and updates active to awaiting_payment in one transaction. Tests inject order-set and session-update failures and prove the order/session/guard state is unchanged.
- Before any new-order write, an active session must still have checkoutAt and closedAt exactly null and orderId and checkoutBy exactly empty; each malformed initial field is covered with a zero-write assertion.
- Before a new order is created, createTableOrder requires the exact active length-prefixed store/table guard to match owner, store, table, and session. Existing deterministic orders are returned first, including terminal external-paid state.
- markTableOrderExternalPaid updates the order, closes the session, and conditionally removes only the matching guard in one transaction. Tests inject failure into each write stage and prove full rollback.
- The transaction fake commits from an isolated working copy only after callback success, making rollback assertions behavioral rather than write-call-count mocks.

### Idempotency and state

- The occupancy document ID is deterministic and collision-free for valid components; a committed live guard returns TABLE_OCCUPIED on a second open.
- Checkout uses orderIdForSession. A repeat returns the stored quote only after revalidating owner/store/table relationships, the exact pricing snapshot, trusted timing, safe-integer arithmetic, policy fields, and the complete awaiting-payment or external-paid state.
- A repeat external-paid call returns the existing outcome only after revalidating its owned session/store relationships, complete trusted order snapshot and arithmetic, zero automatic costs, closed session, and immutable audit actor/reason/time.
- Initial and repeated external-paid paths require orderIdForSession(sessionId), outTradeNoForOrder(orderId), and splitNoForOrder(orderId) from the byte-identical deployable state helper.
- closeSession performs no SDK/database access and returns PRODUCT_RETIRED.

### Amount units and trusted time

- Saved table prices are positive safe integer fen. Display yuan is always derived as pricePerHourFen / 100.
- Session pricing snapshots come only from the owned server-side store table and are immutable for the session/order lifecycle.
- Checkout freezes server Date.now once and uses BigInt rational arithmetic equivalent to Math.round(elapsedMs * pricePerHourFen / 3600000), avoiding an inexact Number intermediate. The boundary regression proves the former Number calculation was one fen high at an otherwise valid maximum-safe price.
- The copied calculateSettlement helper derives the 500-basis-point total cost and shop net; channelFeeFen and platformNetFen start as null.
- External settlement zeros automatic cost/channel/platform amounts and assigns the complete paid table fee to shopNetFen.
- Initial externalPaidAt must be a safe integer at or after checkoutAt; invalid trusted-clock values return ORDER_STATE_INVALID before any write.

### Client fail-closed behavior

- createSession, closeSession, addTableOrder, and markTableOrderExternalPaid use callCheckedCloud.
- Cloud-mode saveShopStore also uses callCheckedCloud, so invalid configuration and authorization failures cannot be displayed as successful saves.
- Local-mock saveShopStore rejects an unknown supplied `_id` with STORE_NOT_OWNED and leaves storage unchanged, so Promise-based callers cannot enter their success branch.
- When cloud is unavailable, all four reject with CLOUD_NOT_READY and the test proves no local storage write or cloud call occurs.
- addTableOrder sends only sessionId. Historical/demo read data remains separate from real financial mutation helpers.

## Constraints Confirmed

- No Git initialization, stage, commit, branch, index, or other Git write was performed. A read-only codex-status probe failed with “fatal: Needed a single revision” because the repository has an unborn HEAD.
- No file was deleted.
- No .agents path was read or modified.
- No full verifier was run; final whole-repository verification remains with the root task.
- No file outside the Task 3 list and this report was modified.
