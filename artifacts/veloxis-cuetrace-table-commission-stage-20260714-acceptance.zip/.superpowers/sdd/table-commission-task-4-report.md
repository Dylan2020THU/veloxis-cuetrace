# Task 4 Report — WeChat Pay APIv3 Reference Adapter

## Outcome

Implemented the approved Node.js APIv3 reference adapter, strict server-only configuration loader, raw HTTP event helpers, verified bill downloader/parser, secret ignore rules, and per-file table-finance sync/parity tooling. No payment was created, no real credential was read or printed, no network request was made, no deployment/business state was changed, and no file was deleted, staged, or committed.

The adapter source contains the exact approved disclaimer:

`AI 参考官方 Java 翻译生成，非官方维护。请开发人员自行审查 AI 生成的代码逻辑，上线前充分测试以确保其适用性与准确性，AI 不对生成代码的正确性承担责任。`

## TDD evidence

Meaningful RED evidence captured before the corresponding production changes:

1. `tests/wechatPayV3Adapter.test.js` exited 1 with `MODULE_NOT_FOUND` for the missing `cloudfunctions/_shared/wechatpay-v3/client.js`.
2. `tests/cloudSharedParity.test.js` exited 1 because `scripts/sync-table-finance-libs.ps1` did not exist.
3. The secret-hygiene regression exited 1 because `.gitignore` lacked `.env`.
4. The exact-wire-path regression reached the injected transport instead of rejecting an unencoded path.
5. The review-hardening suite exited 1 with `client.downloadBill is not a function` for the missing official `download_url` contract.
6. After adding the dedicated downloader, the integrated amount-column test exited 1 because `订单金额`/`退款金额` remained strings instead of exact fen integers.
7. After Task 3 added a standalone deployed `state.js`, parity exited 1 because the script lacked the required per-file allowlist.
8. The Windows PowerShell AST regression exited 1 because the sync script's leading `-or` continuations were not valid Windows PowerShell syntax.
9. Non-canonical dot segments and encoded path separators reached the injected transport instead of failing before I/O.
10. The exact-key-size regression exited 1 because generated RSA-1024 merchant and platform keys were accepted; RSA-3072 rejection is covered by the same contract.
11. The raw-header namespace regression exited 1 because bare normalized names such as `timestamp` were accepted as wire headers.
12. A bill containing U+0085 exited through the missing-required-header path instead of the unsafe-control-character path.
13. A physically quoted empty CSV record (`""`) was accepted as the summary separator.
14. The sync parity regression exited 1 because the script had no reusable segment-by-segment ancestor/reparse-point guard.
15. A response signed with a trusted `PUB_KEY_ID_` identifier exited 1 as a malformed serial.
16. After response identifier support, the trusted-key configuration still rejected the official public-key ID shape.
17. After configuration support, an ordinary public-key-mode request omitted the required `Wechatpay-Serial` selection header.

Each RED was followed by the minimum production change and a focused GREEN rerun.

## Final GREEN evidence

Bundled Node:

`C:\Users\15384\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe`

- `node tests/wechatPayV3Adapter.test.js` — exit 0, `wechat pay v3 adapter ok (44 tests)`.
- `node tests/cloudSharedParity.test.js` — exit 0, `cloud shared parity ok (5 explicit copies)`; this includes a real Windows PowerShell parser assertion.
- `node --check` — exit 0 for the two changed tests and all four APIv3 modules (`6` JavaScript files).
- Final discovery found only the canonical `money.js`/`state.js` plus five legitimate deployed copies: two in `createSession/lib`, two in `createTableOrder/lib`, and `markTableOrderExternalPaid/lib/state.js`.

Per the brief, `scripts/codex-verify.ps1` and the full test suite were not run; root owns final repository-wide verification.

## Behavior covered

- Exact APIv3 request canonicalization, rejection of literal/encoded dot or backslash traversal before transport invocation, and `WECHATPAY2-SHA256-RSA2048` authorization.
- Raw-byte response/notification verification, strict freshness, serial lookup, case-insensitive wire headers limited to the `Wechatpay-*` namespace, exact normalized-header validation, and duplicate-header smuggling rejection.
- Mini-program RSA signature, RSA-OAEP SHA-1 encryption, and strict AES-256-GCM resource decryption.
- Signature-first handling for all ordinary 2xx/non-2xx API responses, trusted structured errors only after verification, timeout/live-abort behavior, and sanitized transport errors.
- Certificate-serial and official `PUB_KEY_ID_` response verification, with at most one normalized public-key ID and automatic caller-independent `Wechatpay-Serial` selection on ordinary public-key-mode API requests; certificate-only requests omit it.
- Dedicated official bill download URL validation (`https://api.mch.weixin.qq.com/v3/billdownload/file`), exact encoded path/query signing, intentionally unsigned download response handling, untrusted non-2xx body handling, and SHA1 validation before use.
- Environment-only fail-closed configuration using exactly the ten approved variables, exact RSA-2048 merchant/trusted-platform key enforcement, strict certificate-serial/public-key-ID/URL/name/key checks, normalized duplicate identifier rejection, and no client fallback. The legacy `WXPAY_PLATFORM_CERTS_JSON` name now maps trusted verification identifiers (certificate serials or one public-key ID) to PEM keys without adding an environment variable.
- Strict UTF-8 official backtick CSV, quoted/escaped fields, LF/CRLF, exactly one physical unquoted-empty summary separator, one summary row, exact configured amount-column conversion, C0/C1 control and shape rejection, and timing-safe SHA1 comparison.
- Preserved existing `.gitignore` entries while adding the requested secret patterns.
- Explicit per-file PowerShell copy allowlist with segment-by-segment ancestor type/reparse-point checks, repository-root/file checks, argument rejection, no delete operation, AST syntax coverage, and byte parity tests.

## Files changed

- `tests/wechatPayV3Adapter.test.js`
- `cloudfunctions/_shared/wechatpay-v3/client.js`
- `cloudfunctions/_shared/wechatpay-v3/config.js`
- `cloudfunctions/_shared/wechatpay-v3/http-event.js`
- `cloudfunctions/_shared/wechatpay-v3/bill-parser.js`
- `scripts/sync-table-finance-libs.ps1`
- `tests/cloudSharedParity.test.js`
- `.gitignore`
- `.superpowers/sdd/table-commission-task-4-report.md`

No Task 3 file and no `.agents/**` file was modified.

## Assumptions and residual risks

- Root had already verified the cited official APIv3 signing/decryption/mini-program references and the official bill-download rule. The implementation follows the root-confirmed rule that the dedicated bill file response has no `Wechatpay-*` response signature and instead requires SHA1 verification; ordinary API responses still always require a valid platform signature.
- Root additionally confirmed from the synced official partner documentation that public-key mode uses the exact uppercase `PUB_KEY_ID_` prefix plus 32 hexadecimal characters and selects that key on ordinary requests with `Wechatpay-Serial`; the implementation normalizes only the hex suffix to uppercase and rejects lowercase/lookalike prefixes.
- Tests use only ephemeral in-memory RSA fixtures and an injected transport. Real WeChat interoperability, certificates, credentials, network behavior, and deployment remain intentionally untested.
- Certificate auto-download/rotation, retries, deployment code, and business cloudfunctions are intentionally outside this task.
- The sync script now walks every repository-relative path segment and rejects a reparse-point leaf or ancestor before copying.
- The sync script was syntax-parsed but not executed during focused verification, matching the brief's restricted command set; the parity test verifies all five current deployed files already byte-match their canonical sources.

## Independent review

Independent implementation review initially found one Important Windows PowerShell parsing defect. A failing AST regression was added first, the continuation syntax was corrected, and follow-up review confirmed it was closed. A later review reclassified ancestor junction traversal as Important and identified two bill-parser hardening gaps (C1 controls and a quoted-empty separator); root review also identified path canonicalization, exact RSA-2048 enforcement, raw-header namespace separation, and official public-key-mode compatibility. Each issue received an independently failing regression before its focused fix. Two final read-only reviews (the full remediation scope and a separate public-key-mode security pass) reported no Critical, Important, or Minor finding.
