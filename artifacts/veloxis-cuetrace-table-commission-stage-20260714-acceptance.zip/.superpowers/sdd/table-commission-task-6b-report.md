# Task 6B Refund Lifecycle Freeze Report

Status: `FROZEN_AFTER_FINAL_REVIEW_REMEDIATION`

This report covers only the Task 6B refund lifecycle. It does not claim that
Task 6 as a whole, Task 7 reconciliation, deployment, or real-funds acceptance
is complete.

## Frozen scope

- Added owner-only `requestTableRefund({orderId, refundFen, reason, idempotencyKey})`
  plus the exact `reconcileTableRefundsTimer` recovery trigger.
- Added signed APIv3 `SUCCESS`, `CLOSED`, and `ABNORMAL` refund callback handling
  in `tableRefundNotifyV3`.
- Added shared refund validation, cumulative transition, and CloudBase store
  modules plus byte-identical deployable copies for both cloud functions.
- Added the minimal mini-program `requestTableRefund(input)` data-service
  interface. It forwards only the four allowed fields through
  `callCheckedCloud`; it has no UI or local-success fallback.
- Did not modify the canonical WeChat Pay adapter, library sync/parity scripts,
  `.agents/**`, or unrelated application behavior. The final cross-slice review
  tightened only the profit-sharing scan/assessment invariants documented in
  the Task 6A report.

## Implemented contract

The command accepts exactly four fields, requires owner identity, a positive
safe-integer gross amount, a bounded reason, and a canonical idempotency key.
The refund document ID, refund claim attempt, and split-return number are
deterministic. Each new refund also stores immutable top-level `subMchid` from
the validated order payment-profile snapshot. Replay, timer recovery, query,
and callback transitions reject or review a local `subMchid` mismatch.
Cumulative requested gross refund is capped by the original WeChat order
total; verified payer and coupon refund facts are independently capped by
their original totals. The canonical counter snapshot additionally requires
`grossRefundedFen === refundedTableFeeFen + couponRefundedFen`; unsafe,
understated, or overstated gross facts fail closed. New claims and active owner
replay reject the corrupt snapshot before writes or WeChat Pay calls, and timer
recovery rejects it transactionally before advancing the lease.

For an unsplit order, the handler submits the partner refund directly. For a
completed Task 6A split snapshot, it first creates the required provisional
split return, queries the exact deterministic return to terminal `SUCCESS`, and
only then submits the refund. A processing return blocks the refund; failed,
malformed, conflicting, or otherwise non-authoritative states fail closed.
A recovery invocation always queries the deterministic `out_return_no` first.
Verified `RESOURCE_NOT_EXISTS` resubmits the exact same return body once and
requeries once; an immediate not-found after the initial submission remains
retryable so a later recovery can complete. Full refund returns all remaining
platform split. Provisional split-return facts are explicitly marked for later
adjustment rather than treated as final fee evidence.

The exact partner refund body contains trusted `sub_mchid`, transaction ID,
deterministic refund number, reason, HTTPS callback URL, gross refund, original
gross total, and `CNY`. An accepted application response remains `processing`.
Terminal state is written only by a validated query result or a signed and
decrypted notification. Network-ambiguous submissions are recovered by query
using the same refund number; a verified `RESOURCE_NOT_EXISTS` query may
resubmit only that same deterministic number.

Notification handling verifies the signature over untouched raw bytes before
JSON parsing, requires an exact six-field encrypted-resource envelope, checks
strict envelope `create_time`, and binds `REFUND.SUCCESS`, `REFUND.CLOSED`, or
`REFUND.ABNORMAL` to the matching decrypted status. The decrypted payload is
exact: the four amount facts are `total`, `refund`, `payer_total`, and
`payer_refund`; query-only and currency fields are rejected. `success_time` is
required only for `SUCCESS`. Structurally malformed or event/status-mismatched
callbacks return 400 without writes. Valid negative terminal callbacks write
one deterministic redacted manual-review event and return 204 without a
success event. Query/notification races create one success event and one
cumulative order update.

The five-minute timer accepts exactly
`{Type:'Timer',TriggerName:'reconcileTableRefundsTimer'}` and only a missing or
empty `OPENID`; caller-bearing or malformed invocations perform no database or
WeChat Pay work. It reads at most 20 deterministically ordered due refunds,
transactionally advances each claim lease and next-attempt time, then queries
authoritative split-return/refund status. Fixed-time two-round coverage proves
that item 21 is not starved. Definitive verified 4xx failures enter manual
review; transport failures, 5xx, 429, and other uncertain outcomes remain
retryable.

Official response and notification timestamps are parsed by a strict RFC3339
calendar validator. It rejects impossible dates, invalid time components, and
out-of-range offsets instead of accepting JavaScript `Date.parse`
normalization. Task 6A completion snapshots accept the three persistence forms
actually produced by the system: a nonnegative safe-integer epoch value, a
valid `Date`, or a strict RFC3339 string, and compare normalized milliseconds.
Query `create_time`/`success_time`, notification `success_time`, and envelope
`create_time` all pass through the strict validator.

After verified success, the order persists cumulative gross, payer-cash, and
coupon refund facts, recalculates the 500-bps total cost from retained payer
cash, and recalculates shop net/settlement. Full verified refund sets retained
cost to zero. Pre-refund channel-fee/platform-net evidence is retained in audit
snapshot fields, while current `channelFeeFen`, `platformNetFen`, and
`channelFeeEvidenceHash` are cleared. The order is marked
`refundFeeReconciliationStatus: 'pending'` and
`financeAutomationBlocked: true` until Task 7 supplies official bill evidence.

## Frozen Task 7 handoff fields

- Refund terminal identity: `status: 'succeeded'`, `refundNo`,
  `wechatRefundId`, `orderId`, immutable `subMchid`, and `refundCompletedAt`.
- Official time evidence: numeric `requestedAt`; query/application
  `refundCreateTime` and numeric `refundCreatedAt` when available.
- Verified amounts: `refundFen`, `payerRefundFen`, `couponRefundFen`, plus
  optional query-only settlement/discount fields.
- Split-return evidence: `splitReturnNo`, `splitReturnFen`,
  `wechatSplitReturnId`, `splitReturnBasis`, and
  `splitReturnAdjustmentStatus`.
- The response-reported `reportedRefundFeeFen` is not final reconciliation
  truth. Task 7 must establish refund-fee/channel-fee facts from official bill
  rows before unblocking finance automation.

## Required CloudBase indexes

The timer's bounded due scans require these `shop_refunds` composite indexes
before deployment (ascending fields in the order shown):

1. `schemaVersion`, `status`, `refundNextAttemptAt`, `requestedAt`, `_id`.
2. `schemaVersion`, `status`, `refundNextAttemptAt`,
   `refundClaim.leaseExpiresAt`, `requestedAt`, `_id` for legacy records where
   `refundNextAttemptAt` does not exist.

No index was created or deployed by this subtask. Task 7 owns any additional
merchant/time reconciliation indexes that consume `subMchid`.

## Important independent-review findings remediated

- An immediate verified split-return `RESOURCE_NOT_EXISTS` after the initial
  submission incorrectly entered manual review. It now stays retryable, and a
  later recovery performs the bounded query/resubmit/requery sequence.
- Timer authorization previously treated a non-string `OPENID` as empty. Timer
  context now permits only an absent property or the exact empty string, before
  any database or WeChat Pay operation.
- Task 7 could not safely scope refund reconciliation by merchant. New refunds
  now persist immutable top-level `subMchid`, and all existing-refund paths
  enforce it against the validated order snapshot.
- Refund counter validation independently bounded gross, payer, and coupon
  values but did not prove that gross equaled payer plus coupon. Both under- and
  over-stated snapshots now fail `refundCounters`/`validRefundOrder`, including
  active owner replay and timer recovery before side effects.
- A later narrow review found that terminal `succeeded`/`manual_review`
  idempotent replays returned before checking the same counter identity. Both
  terminal branches now require `refundCounters(order)` first; corrupt snapshots
  fail with `ORDER_STATE_INVALID` without writes or network calls, while a valid
  fully refunded order still replays `succeeded` without I/O.

No unresolved Important finding remains in the Task 6B scope.

## TDD evidence

Observed RED states before their corresponding implementation changes included:

- missing shared refund module (`MODULE_NOT_FOUND`);
- invalid Task 6A split snapshots entering the refund path;
- accepted/terminal refund ID conflict not entering manual review;
- missing official refund creation time evidence;
- callback-before-application-response race returning a state-change error;
- verified refund query not-found failing to reuse the deterministic number;
- missing provisional split-return adjustment fields;
- impossible `2026-02-31` being normalized and accepted as an official time;
- missing mini-program `requestTableRefund` export;
- Task 6A `Date`/JSON ISO completion snapshots being rejected;
- callback extra fields and event/status mismatch being accepted;
- no timer guard, recovery claim, bounded due query, or fairness behavior;
- immediate split-return not-found incorrectly becoming manual review;
- non-string timer `OPENID` bypassing the empty-context requirement;
- missing immutable refund `subMchid` evidence;
- under- and over-stated gross counters being accepted despite disagreeing
  with payer plus coupon refund facts;
- the first active-snapshot guard placement breaking terminal full-refund
  idempotent replay before it was narrowed to the counter identity check;
- terminal `succeeded` replay returning success for a corrupt refund-counter
  identity before the counter check was moved ahead of both terminal branches.

The focused suite is now 31 tests and covers exact owner input, authorization,
cumulative gross/payer/coupon bounds, pre/post-split ordering, mandatory split
return query, exact not-found resubmission, deterministic replay, persisted and
official timestamps, partial/multiple/full refund math,
accepted-versus-terminal state, strict raw callback contracts, negative
terminal handling, timer loss recovery, bounded/fair scans, timer/owner races,
4xx versus uncertain error classification, immutable merchant scope, exact
gross/payer/coupon counter identity and side-effect-free corrupt recovery,
deployable package metadata, byte-identical local refund copies, and the exact
fail-closed owner service payload.

## Files in this freeze

- `tests/tableRefunds.test.js`
- `cloudfunctions/_shared/table-refund/{table-refund.js,refund-transition.js,cloudbase-refund-store.js}`
- `cloudfunctions/requestTableRefund/{index.js,package.json,config.json}` and its nine
  deployable `lib/**` dependency copies
- `cloudfunctions/tableRefundNotifyV3/{index.js,package.json}` and its nine
  deployable `lib/**` dependency copies
- `miniprogram/services/data.js`

## Verification boundary

The final focused verification after implementation and report creation was:

```text
table profit sharing ok (13 tests)
table refunds ok (31 tests)
SYNTAX=PASS COUNT=9
JSON=PASS COUNT=5
TASK6_BYTE_PARITY=PASS COUNT=7
```

Task 7B's global sync completed before this final gate. The seven targeted
canonical/deployed Task 6 helper comparisons were already identical; no
overwrite conflict or additional sync was required. The scoped final
self-review conclusion is Critical 0 / Important 0. The same independent
reviewer then rechecked the terminal replay remediation and reported Critical
0 / Important 0 / Minor 0, PASS.

No full test run or `scripts/codex-verify.ps1` was run by this subtask; the root
task owns the one final repository-wide verification. No Git command, network
synchronization, deployment, real WeChat Pay request, or file deletion was
performed.

Real acceptance remains external until approved service-provider and special
merchant accounts, authorization, keys, HTTPS callback routes, next-day bills,
and a small real-funds payment/split/partial-refund/full-refund cycle have been
verified.
