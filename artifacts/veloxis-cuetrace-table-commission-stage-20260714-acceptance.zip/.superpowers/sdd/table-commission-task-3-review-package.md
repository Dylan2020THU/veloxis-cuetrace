# Task 3 Review Package

## Baseline

- Repository is unborn `main`; `HEAD` and a Git diff do not exist.
- Base: `WORKTREE_AFTER_TASK_2`; Head: `WORKTREE_AFTER_TASK_3`.
- Current files and hashes below are the complete Task 3 review snapshot. Do not run Git or crawl unrelated files.

## Contract and report

- `.superpowers/sdd/table-commission-task-3-brief.md` — 171 lines — `dae87347ee38e4626f74ad7bde0350c0913954542f92c2b41f6693121381182d`.
- `.superpowers/sdd/table-commission-task-3-report.md` — 207 lines — `287c90ddb8c1400af1b5060a3bbcd7a31eb96b38494e8af839e04017a3e199cc`.
- `tests/tableSessionOrderFlow.test.js` — 1477 lines — `5a281d130aca56d0eb0eac6fec4de02062a6168ed8306423bb49473e913f67da` (complete behavior test, including all review regressions).

## Deployable finance copies

- `cloudfunctions/createSession/lib/money.js` — 98 — `16974e2a20e94fc650607d98ad293875ddd8a705fe07a14f47fbf4364fc4a6f4`.
- `cloudfunctions/createSession/lib/state.js` — 127 — `f1869a003e76911d877917f2bef38a99e24d07cba96816307527516771587e67`.
- `cloudfunctions/createTableOrder/lib/money.js` — 98 — `16974e2a20e94fc650607d98ad293875ddd8a705fe07a14f47fbf4364fc4a6f4`.
- `cloudfunctions/createTableOrder/lib/state.js` — 127 — `f1869a003e76911d877917f2bef38a99e24d07cba96816307527516771587e67`.
- `cloudfunctions/markTableOrderExternalPaid/lib/state.js` — 127 — `f1869a003e76911d877917f2bef38a99e24d07cba96816307527516771587e67`.

The hashes match the approved shared money/state modules from Task 1.

## Cloud implementation

- `cloudfunctions/saveShopStore/index.js` — 207 — `36f42e5e7f33f7d220e882f9cefefdf8b011cff83a3ea67dfc52e6d6bbf526fd`.
- `cloudfunctions/createSession/index.js` — 203 — `b56858f303395d24969143aa14a36b4fe3080715c93f7535c64547de7a2056a3`.
- `cloudfunctions/getSessions/index.js` — 69 — `890dc85e9041b54bb079530aa3c7f665e228f9326e230c0bf3982a0ec7780591`.
- `cloudfunctions/closeSession/index.js` — 4 — `939c218425ede700431bf0d43c18ae20cde63e7f76757976463823969e7d0650`.
- `cloudfunctions/createTableOrder/index.js` — 416 — `719aef71123b4a6cc881cbbf37a9573c05af4ccc8e5f20e8eee499e7ca2997af`.
- `cloudfunctions/markTableOrderExternalPaid/index.js` — 368 — `5aa3315ee21640ebbdd2aeaeb1203cd38f35c2ee952cfaedfa0d3676fce72218`.
- `cloudfunctions/markTableOrderExternalPaid/package.json` — 9 — `d0ba6ee5bcc083f6bc405bc7454de150c5548b7f6432da8b4cb60fec3fdf46dd`.

## Client implementation

- `miniprogram/pages/shop/table-types/index.js` — 211 — `3dbce7372253a41bc557955da6b07caf5ddfdb5612dd955d7cfbac4b27587fda`.
- `miniprogram/pages/shop/brand-add/index.js` — 198 — `e4c5c25104cedd4ae1b20af8878298277f827c74164df7a22ea552f603fd50cc`.
- `miniprogram/services/data.js` — 2601 — `779f87786578f684c56ebf3ad88901d577aec88c99dd55306cf627425114fc52`; Task 3 focus ranges are `saveShopStore` 980-1025, session mutations 1047-1062, and trusted order/external-paid helpers 2445-2456. Do not review unrelated service code.

## Mandatory review risks

- Verify the second-cycle missing-document fix matches actual optional-read behavior and did not turn a client-supplied unknown `store._id` into an unauthorized create/update path.
- Verify store/table components obey the 1-64 character allowlist and that the store-length-prefixed occupancy mapping is injective, including boundary-underscore pairs such as `(a_, b)` versus `(a, _b)`; verify duplicate/cross-owner occupancy cannot cause collision or leakage.
- Verify transactions return business failures without partial commit, require exact owner/store/session/order/guard relationships, and behave correctly if the guard is missing or belongs to another session.
- Verify a new order is written only when its active session has checkoutAt/closedAt exactly null and orderId/checkoutBy exactly empty; each malformed initial field must return SESSION_STATE_INVALID with zero writes.
- Verify existing-order idempotency does not return malformed/foreign/incorrect-session quotes, rejects `checkoutAt < startedAt` even when amounts are synchronized to zero, and correctly supports a valid terminal external-paid retry without new writes.
- Verify BigInt price calculation is exactly half-up equivalent to the approved positive-number formula and rejects unsafe output.
- Verify external-paid initial conversion and idempotent retry validate the complete pricing snapshot, time/duration, gross/paid, policy, financial, and audit relationships; synchronized gross/paid/shopNet or snapshot corruption must fail closed. Both paths must require state-helper products for orderId, outTradeNo, and splitNo. Initial externalPaidAt must be a safe integer at or after checkoutAt before any write. Also verify zero automatic cost, session closure, and release-only-matching guard behavior when a guard is missing or mismatched.
- Verify markTableOrderExternalPaid deploys the exact shared state.js bytes and does not deploy an unused money.js copy.
- Verify the client cannot fall back to local success when cloud is unavailable; cloud-mode `{ok:false}` and local-mock unknown supplied store IDs must both reject rather than fulfill a Promise failure value.
- Verify the 1477-line test has meaningful assertions for every claimed rollback/idempotency path and does not merely model away real CloudBase/document-ID behavior.

## Review constraints

- Read-only: no edits, Git, `.agents/**`, or broad codebase crawl.
- Treat the implementer report and its prior internal review as unverified claims.
- The implementer already ran the focused suite and syntax checks. Run one focused command only if a concrete code-reading doubt cannot be resolved otherwise.
- Return spec compliance and code quality separately, with exact file:line evidence and Critical/Important/Minor severity.
