# Task 2 Review Package

## Baseline

- Repository: unborn `main`; no `HEAD`, base commit, staging, or meaningful Git diff exists.
- Base: `WORKTREE_AFTER_TASK_1`; Head: `WORKTREE_AFTER_TASK_2`.
- The current files listed below, frozen by line count and SHA-256, are the complete Task 2 review surface. Do not crawl unrelated files or run Git commands.

## Contract and evidence

- Brief: `.superpowers/sdd/table-commission-task-2-brief.md` — 67 lines — `4ae34d2762ed3f510dda0ed1c698730f260a749987ee5527ec87cc394aaeb860`.
- Implementer report: `.superpowers/sdd/table-commission-task-2-report.md` — 110 lines — `4d253ce24a4073578bee6b6ee1e07a04da79acff7427164efae79f2552909da1`.

## Tests

- `tests/legacyBillingRetirement.test.js` — 371 — `10545d29c54d7d5c752e17a2796cb4975df851db6c229918d1129ae9470159be` (new in full).
- `tests/coachCommissionRetirement.test.js` — 290 — `2a570de114f90f9da4fb04b8fa08d691cd8844c60f426b9d8e09b24431394b7e` (new in full).
- `tests/shopSubscriptionPlans.test.js` — 51 — `eb024215f5706339f86bda2caa65abab63078216ed5507fe77fa1a1be8f6a1a3` (rewritten retirement expectations).
- `tests/recurringCloudFunctions.test.js` — 55 — `f46b8e661d1242eb39e78a2d1ad7b1ca26bbce751ee63488fa2c7530d25c2b27` (rewritten retirement expectations).
- `tests/recurringSubscriptionGuard.test.js` — 1036 — `89725d1ceade1e182ea8d21e67f8b5fbbae0a188dac2a244b6b1acc4e87a0bba`; Task 2 delta is the retired create-contract test at current lines 353-369 and its test-list entry at line 994. Callback/cancel/delete-account coverage after that remains context and must not have been weakened.

## Billing and client surface

- `miniprogram/utils/billing.js` — 239 — `7da1c40ae8b234440ecc11bc0dd0d3753ba048df9993169ae7cee1d46c4498c6`; focus on zero coach rate and compatibility APIs at lines 12 and 143-215.
- `miniprogram/components/paywall/index.js` — 21 — `c7ef143b1027fc9b840bf59191674244815b862326a698eb64b295bc94fe4d37` (current file in full).
- `miniprogram/app.js` — 147 — `f04545449bf0739014575dca525a8a672ede82edc122ac19fa1ec19a0dca1a76`; compatibility `paywall` is at the end of the file.
- `miniprogram/app.json` — 112 — `71f8b6bdb503c786555590c9dca1aec02d292aefd680cb03c3cc5551c520b878`.
- `miniprogram/services/data.js` — 2610 — `bf9d063a239488f021ae7757a80721fe3c78efe411628e2004b28859556c67ae`; Task 2 review ranges: table-verification coach amount at 1139-1179, mock coach settlement at 1225-1315, mock booking around 2135-2165, and retired purchase interfaces at 2380-2403. Cancellation/history helpers at 2405-2424 remain intentionally active/readable.

## Shop/profile/legal UI

- `miniprogram/pages/shop/dashboard/index.js` — 81 — `e23f7a99a336f155448eb470e45d9bbe9aaa650a83629a949333efe875c78635`.
- `miniprogram/pages/shop/dashboard/index.wxml` — 78 — `cca8de147b5ebea8ea69bfcac4acd601a88b1459fdb9d6422ff01aaa1bda4a4c`.
- `miniprogram/pages/profile/index.js` — 356 — `9a7e26c82b8d168a019ed4d628e6260752e42b5c25e3222ed28161de967da20a`.
- `miniprogram/pages/profile/index.wxml` — 161 — `08556b0fecf6f166d46d0e05b745d036dd046c54b033b2436e4b08075f74cfc0`.
- `miniprogram/pages/shop/brand-add/index.js` — 195 — `a89518ed5d4f2d1d63a543dfadd41f98dbfd40ed319bc3518a758fede5115aba`.
- `miniprogram/pages/legal/index.js` — 86 — `ac3ce55f1b1f73eb122097c98328b14e66f0a4204ad335d6b431ab0439b24d3b`; Task 2 legal delta is the compatibility owner-service text at current lines 55-70.

## Retired cloud entry points

These five current files are each 6 lines and identical, returning only `PRODUCT_RETIRED`:

- `cloudfunctions/upgradePlan/index.js`
- `cloudfunctions/createPayOrder/index.js`
- `cloudfunctions/createVirtualPayOrder/index.js`
- `cloudfunctions/createRecurringContract/index.js`
- `cloudfunctions/createRecurringDebit/index.js`

Each has SHA-256 `c1fa8552026cd1f38864b746a7a3d7ea6afd7b42642e84dde626da24ed751ee9`.

- `cloudfunctions/createRecurringDebit/config.json` — 3 — `82177e11b5c240fc8822fbc7d92dae03e6270a3b6c447fd94671ce36439268fb`.

## Coach cloud/UI surface

- `cloudfunctions/createBooking/index.js` — 28 — `9117b42b928851ea7deabdf7ac880ffd79347694070c43b60a5195deabc8844f`.
- `cloudfunctions/getShopCoachSettlement/index.js` — 95 — `8d5fadecd105e38a86e5190b68dd53299a080d2490a61e41eea5bd21e6fd7267`.
- `cloudfunctions/getCoachSettlementDetail/index.js` — 54 — `b18e93faec367c4cb5eea40f097fb3fff8f65f43eeba2f4e9fc54d2c02313126`.
- `cloudfunctions/settleCoach/index.js` — 68 — `9997c790a521ccdfc6a1833c90a0bb00eac6cf180a413d16a6823c823b58de1b`.
- `cloudfunctions/recordVerifiedTraining/index.js` — 46 — `6c9b79ba82f642b40bb3f3032d5481898582474b598c3babcb36d94d4cece19a`.
- `miniprogram/pages/coach/bookings/index.js` — 30 — `b6d448ec8219a9aa49797ecec7fcef3d2f85fa8154e613cb0bc9d78b5b541d48`.
- `miniprogram/pages/coach/bookings/index.wxml` — 22 — `3be0866ac9ea457d4ea9f9881fe342e84046fefa357ab4cf75d007dc000d9c15`.
- `miniprogram/pages/shop/coach-settlement/index.wxml` — 62 — `be098f65bd56d59b4fb40c2257772b2a5eb10774f4d23a939f28fd56a5e94f85`.

## Review constraints

- Read-only review; do not edit files, invoke Git, or inspect `.agents/**`.
- Treat report claims as unverified. Check that active charge paths fail before writes/network, free access does not invoke a paywall, cancellation/history remain usable, new/unsettled coach commission is zero, settled snapshots remain authoritative, and the tests exercise real behavior with meaningful assertions.
- The implementer already ran the six focused tests and 24 syntax checks. Run only one focused command if a concrete code-reading doubt cannot otherwise be resolved.
- Return both spec-compliance and code-quality verdicts with exact file:line evidence.
