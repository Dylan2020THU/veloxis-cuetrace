# Task 6A Report — T+1 Profit Sharing

Status: `FROZEN_AFTER_FINAL_REVIEW_REMEDIATION`

## Frozen scope

This report covers only the root-authorized Task 6A slice:

- complete the reviewed APIv3 adapter with signed split, split-return, and
  refund query wrappers;
- bind encrypted receiver names and `Wechatpay-Serial` to one exact trusted
  key identifier;
- implement the timer-only T+1 profit-sharing claim, terminal query, verified
  unfreeze, immutable event, and deployable-copy lifecycle;
- retain the existing 35 literal shared-library destinations and append only
  the seven Task 6A destinations.

Refund commands/notifications, Task 7 bill import, reporting, Hall UI,
deployment, network calls, credentials, and real-funds acceptance are outside
this frozen slice.

## TDD evidence

Meaningful RED states were observed before production changes:

1. The adapter suite exited 1 because `ENV_NAMES` omitted the new optional
   `WXPAY_ENCRYPTION_KEY_ID`; the same RED also contained the three missing
   query wrappers and sensitive request/header assertions.
2. `tests/tableProfitSharing.test.js` exited 1 with `MODULE_NOT_FOUND` for the
   missing `settleTableProfitSharing/index.js`.
3. After settlement behavior became green, its deployability test exited 1
   with `ENOENT` for the missing function package/config and local adapter
   copies.
4. The evidence-key regression exited 1 when the helper still accepted the
   old order-only `channel_fee_confirmed` event ID instead of the append-safe
   `orderId:evidenceHash` business key required by Task 7.
5. `tests/cloudSharedParity.test.js` exited 1 with an exact 35-versus-42
   allowlist mismatch before the seven Task 6A literal entries and guarded
   canonical source directory were added.
6. The independent-review evidence regression exited 1 because an arbitrary
   64-hex hash with no official source, artifact, row, or T+1 confirmation
   metadata was still eligible.
7. The retained-amount regression exited 1 because inconsistent payer,
   coupon, and gross-refund counters were ignored.
8. The stale-candidate regression exited 1 because a second worker could
   re-read a completed order and downgrade it to `manual_review`.
9. The fairness regressions exited 1 before pending assessment persisted a
   due time and before the production store issued separate bounded due and
   virgin-field queries.
10. The final production-store pressure regression exited 1 because 20 virgin
    records received `Number.MIN_SAFE_INTEGER` merge priority and displaced a
    due retry; the inverse pressure case protects virgin progress as well.
11. The final fully-refunded reviewer example exited 1 because a 10,200-fen
    order with 10,000 payer fen but only 100 of 200 coupon fen refunded was
    still assessed as eligible.

Each RED was followed by the minimum corresponding production change and a
focused GREEN rerun.

## Frozen adapter contract

- `querySplit(outOrderNo, {sub_mchid, transaction_id})` performs signed `GET
  /v3/profitsharing/orders/{out_order_no}`.
- `querySplitReturn(outReturnNo, {sub_mchid, out_order_no})` performs signed
  `GET /v3/profitsharing/return-orders/{out_return_no}`.
- `queryRefund(outRefundNo, {sub_mchid})` performs signed `GET
  /v3/refund/domestic/refunds/{out_refund_no}`.
- All three wrappers encode the path identifier, construct query fields in the
  approved order, and reject missing or additional query keys before I/O.
- `WXPAY_ENCRYPTION_KEY_ID` is optional. An explicit value must exactly name a
  key already trusted by `WXPAY_PLATFORM_CERTS_JSON`. When omitted, the loader
  selects the configured WeChat Pay public-key ID, otherwise the sole trusted
  certificate; multiple certificates without explicit selection fail closed.
- Config exposes only the selected `encryptionKeyId` and parsed
  `encryptionPublicKey`. `addReceiver` and `split` set `Wechatpay-Serial` to
  that same identifier, while the legal name is RSAES-OAEP/SHA-1 ciphertext.
  Caller-supplied headers cannot override the selection.

## Frozen settlement contract

- The entry point accepts only exact `{Type:'Timer',
  TriggerName:'settleTableProfitSharingTimer'}` and rejects caller/runtime
  `OPENID` contexts before reads, claims, or network calls.
- The scan is bounded to 20. Each order is re-read with its deterministic
  payment and official-fee events in a transaction, claimed as
  `splitClaim:{attemptId,status:'processing',claimedAt,leaseExpiresAt}`, and
  every adapter call occurs after the transaction closes. Only that attempt
  can finalize. The transaction first rechecks the exact current candidate
  state, so a stale list result cannot rewrite a succeeded or otherwise
  non-candidate order.
- Eligibility requires schema-v2 identity, immutable standard policy and
  payment-profile snapshots, verified payment evidence, exact current retained
  amount math, unblocked automation, no `refundClaim` in `returning` or
  `processing`, and official fee evidence matching the lowercase SHA-256
  `channelFeeEvidenceHash`.
- The official fee event ID is
  `financialEventId('channel_fee_confirmed',
  orderId + ':' + channelFeeEvidenceHash)`. An old order-only event cannot
  authorize a split, so refund-adjusted evidence remains append-only.
- Official fee evidence additionally requires `source:'wechat_trade_bill'`,
  strict real-calendar `paymentBillDate`, `confirmedAtMs`, sorted correlated
  `artifacts[{billDate,artifactId,sha1}]`, and sorted
  `rows[{kind,billDate,artifactId,rowIdentityHash,feeFen,...}]`. The unique
  payment row must exactly identify the order; refund fees are negative; every
  row references a listed artifact; and row fees sum exactly to
  `channelFeeFen`. The payment bill date comes from `wechatSuccessTime` in
  Beijing time, every artifact is no later than yesterday, and confirmation
  is between 10:00 Beijing on the day after the latest artifact and `now`.
- `paid`, `partially_refunded`, and the zero-retained `refunded` branch are
  supported. Partially/full-refunded orders use current
  `paidTableFeeFen/totalCostFen/channelFeeFen/platformNetFen`, plus
  `retainedCouponSubsidyFen`; an active refund blocks settlement.
- Paid orders require zero refund counters and full retained payer/coupon
  values. Partial refunds require safe-integer payer, coupon, and gross-refund
  conservation equations. A `refunded` order additionally requires gross
  refund equal to the original total, payer refund equal to the original payer
  total, coupon refund equal to the original coupon subsidy, and both retained
  payer and retained coupon equal to zero before settlement can be eligible.
- Every pending assessment atomically advances `splitNextAttemptAt` without
  regressing a newer value. Production scans use separate indexed due and
  missing-field queries. Results are sorted within their own
  due/`paidAt`/`_id` or virgin `paidAt`/`_id` class, then selected by stable
  due-first alternation. Twenty virgin records cannot displace a due retry,
  and twenty due retries cannot prevent a virgin record from progressing.
- `channelFeeFen > totalCostFen`, malformed/conflicting evidence, unknown
  terminal states, failed/missing/duplicate/mismatched receivers, and changed
  evidence at final CAS enter `manual_review`. Missing not-yet-imported official
  evidence remains pending and cannot move money.
- Positive platform net first idempotently adds the exact service-provider
  `MERCHANT_ID` receiver, requests one exact encrypted receiver with
  `unfreeze_unsplit:false`, then ignores the accepted response as non-terminal.
  Signed query must be `FINISHED` with exactly the expected
  type/account/amount/description and `SUCCESS` result before unfreeze.
- Zero platform net skips both receiver-add and split, and goes only through
  the verified unfreeze path. Unfreeze uses a separate deterministic
  `unfreezeNo`, is queried through the same signed split-query API, and must
  finish with the exact special-merchant receiver and settlement amount.
- Success writes one deterministic `profit_sharing_succeeded` financial event
  and finalizes `splitStatus:'succeeded'`, split/unfreeze identifiers, and
  `splitCompletedAt`. Production `splitCompletedAt` and
  `splitClaim.completedAt` deliberately retain the CloudBase
  `store.serverDate()` Date shape; this remediation does not convert them to
  integer milliseconds. The plaintext legal name is neither persisted nor
  logged.

## Deployability and parity

`settleTableProfitSharing` has its own package and exact timer config. Its index
imports no parent `_shared` path. The Task 6A profit-sharing helper is
byte-identical to its local deployable copy, and the function carries local
copies of:

- all four `wechatpay-v3` modules;
- `table-finance/money.js` and `state.js`;
- canonical `table-profit-sharing/table-profit-sharing.js`.

The sync script still rejects arguments, path escapes, wrong leaf/ancestor
types, and reparse points, and contains no delete operation. Its literal
allowlist preserves the original 35 entries in order and appends seven Task 6A
entries; the last Task 6A-owned sync summary was
`TABLE_FINANCE_SYNC_OK copied=42`. Task 7B later completed its global sync.
The final Task 6 remediation rechecked canonical/deployed profit and refund
helpers after that sync; all seven targeted byte comparisons matched, with no
overwrite or conflict to reapply.

## Focused verification evidence

Bundled Node:

`C:\Users\15384\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe`

- profit sharing: 13/13 groups passed;
- refund lifecycle regression: 30/30 tests passed;
- final narrow static gate: nine JavaScript syntax checks and five JSON parses
  passed;
- canonical/deployed Task 6 helper parity: seven exact byte comparisons
  passed.

Before this final review remediation, the original Task 6A boundary had also
passed adapter 46/46, parity 42, Task 5 payment backend 19/19, checkout token
6/6, checkout page, and all 10 trusted session/order-flow groups. Those broader
gates were not rerun by this narrow subtask. Per task instructions,
`scripts/codex-verify.ps1`, the full suite, Git, deployment, network, and real
merchant operations were not run.

## Files changed

- `tests/wechatPayV3Adapter.test.js`
- `tests/tableProfitSharing.test.js`
- `tests/cloudSharedParity.test.js`
- `cloudfunctions/_shared/wechatpay-v3/client.js`
- `cloudfunctions/_shared/wechatpay-v3/config.js`
- `cloudfunctions/_shared/table-profit-sharing/table-profit-sharing.js`
- `cloudfunctions/settleTableProfitSharing/**`
- the existing deployed `wechatpay-v3/client.js` and `config.js` copies under
  `createTablePayOrder`, `tablePayNotifyV3`, and `reconcileTablePayments`
- `scripts/sync-table-finance-libs.ps1`
- `.superpowers/sdd/table-commission-task-6a-report.md`

No file was deleted. No `.agents/**`, Hall/Task 7 business file, Git state,
credential, or external system was modified. The final refund-invariant files
changed by the cross-slice review are listed in the Task 6B report.

## External acceptance boundary and freeze

All tests use in-memory stores, generated RSA fixtures, and injected transports.
Local GREEN evidence cannot establish service-provider/special-merchant
authorization, live receiver-name matching, actual next-day bill evidence,
callback routes, key/certificate configuration, WeChat asynchronous timing, or
real-funds split/unfreeze behavior. Release remains disabled until those
merchant-console and small real-payment checks are approved and completed.

Task 6A final-review remediation is frozen after its 13/13 focused behavior
gate and the combined narrow Task 6 static/parity checks. The scoped self-review
conclusion is Critical 0 / Important 0. Only findings directly caused by this
slice are in scope; refund details remain in the separate Task 6B report.
