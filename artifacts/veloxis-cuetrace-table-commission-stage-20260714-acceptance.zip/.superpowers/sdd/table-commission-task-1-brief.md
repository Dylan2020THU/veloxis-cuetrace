## Task 1: Verification Harness and Finance Core

**Files:**
- Create: `tests/tableCommissionMath.test.js`
- Create: `tests/tableFinanceState.test.js`
- Create: `tests/codexVerifyUnborn.test.js`
- Create: `cloudfunctions/_shared/table-finance/money.js`
- Create: `cloudfunctions/_shared/table-finance/state.js`
- Modify: `scripts/codex-verify.ps1`

### Binding requirements

- Every amount is an integer number of fen.
- Standard policy is immutable `table_commission_v1`: `billingMode=table_commission`, `commissionRateBps=500`, `includesChannelFee=true`, `splitCycle=T_PLUS_1`.
- `totalCostFen = round(paidTableFeeFen * 500 / 10000)`; `shopNetFen = paidTableFeeFen - totalCostFen`; `platformNetFen = totalCostFen - actualChannelFeeFen`.
- Unknown channel fee stays `null`. If the actual fee exceeds total cost, preserve the negative `platformNetFen` for evidence and return `manualReview=true`; never reduce shop net.
- Refund recalculation uses original paid amount minus cumulative refund, not incremental rounded deltas. Full refund produces zero retained amount and zero total cost.
- Allowed state values and transitions are those in the approved plan. Business identifiers must be deterministic, limited to documented WeChat lengths, and use only `[0-9A-Za-z_@*-]`.
- Approved state values and transitions are:
  - `session`: `active|awaiting_payment|closed`; allow `active->awaiting_payment` and `awaiting_payment->closed`.
  - `order`: `awaiting_payment|complete|external_paid|canceled|manual_review`; allow `awaiting_payment->{complete,external_paid,canceled,manual_review}`, `complete->manual_review`, and `manual_review->{complete,canceled}`. `external_paid` and `canceled` are terminal.
  - `payment`: `not_applicable|unpaid|paid|partially_refunded|refunded|closed`; allow `unpaid->{paid,closed}`, `paid->{partially_refunded,refunded}`, and `partially_refunded->{partially_refunded,refunded}`. `not_applicable`, `refunded`, and `closed` are terminal.
  - `split`: `not_applicable|pending|processing|succeeded|failed|reversed`; allow `pending->{processing,failed}`, `processing->{succeeded,failed}`, `failed->processing`, and `succeeded->reversed`. `not_applicable` and `reversed` are terminal.
  - For every kind, `from === to` is an allowed idempotent no-op. Unknown kinds, unknown states, and unlisted transitions must throw.
- Repository is unborn. Do not initialize Git, stage, commit, or delete files. Preserve unrelated files.
- Follow strict TDD: write test, run it with the bundled Node executable and capture the expected RED failure, then implement minimum code, then rerun GREEN.
- Use `apply_patch` for edits.

### Steps

1. Write RED tests for integer-fen validation, 500-bps rounding, 95% shop net, unknown fee, fee over total cost, zero/full refund, multi-partial-refund recomputation, and decimal-yuan string conversion.
2. Implement this exact public API in `money.js`:

```js
const STANDARD_POLICY = Object.freeze({
  policyVersion: 'table_commission_v1',
  billingMode: 'table_commission',
  commissionRateBps: 500,
  includesChannelFee: true,
  splitCycle: 'T_PLUS_1'
});

function calculateSettlement(paidTableFeeFen, channelFeeFen, policy = STANDARD_POLICY) {}
function recalculateAfterRefund(originalPaidFen, cumulativeRefundFen, netChannelFeeFen, policy = STANDARD_POLICY) {}
function yuanTextToFen(value) {}
```

3. Write RED tests for session/order/payment/split transitions and deterministic IDs.
4. Implement `assertTransition(kind, from, to)`, `orderIdForSession(sessionId)`, `outTradeNoForOrder(orderId)`, `splitNoForOrder(orderId)`, `refundNoForOrder(orderId, idempotencyKey)`, and `financialEventId(type, businessId)`.
5. Write a RED static test for unborn support in `codex-verify.ps1`.
6. Modify the verifier to detect whether `HEAD` exists. With no `HEAD`, set tracked files and diff output to empty, collect untracked files, and continue JS syntax/text/named-test checks. With a normal branch, preserve current merge-base behavior.
7. Run these commands and record exact output:

```powershell
& 'C:\Users\15384\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe' tests\tableCommissionMath.test.js
& 'C:\Users\15384\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe' tests\tableFinanceState.test.js
& 'C:\Users\15384\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe' tests\codexVerifyUnborn.test.js
& 'C:\Users\15384\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe' --check cloudfunctions\_shared\table-finance\money.js
& 'C:\Users\15384\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe' --check cloudfunctions\_shared\table-finance\state.js
```

### Report contract

Write `.superpowers/sdd/table-commission-task-1-report.md` with:

- status `DONE`, `DONE_WITH_CONCERNS`, `NEEDS_CONTEXT`, or `BLOCKED`;
- RED commands and why each failed;
- files changed and concise behavior summary;
- GREEN commands and exact pass/fail summary;
- self-review findings;
- confirmation that no Git operation and no file deletion occurred.
