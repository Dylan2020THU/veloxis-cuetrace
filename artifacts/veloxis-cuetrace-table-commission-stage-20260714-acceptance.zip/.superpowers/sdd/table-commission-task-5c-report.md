# Task 5C 小程序公共结账页冻结报告

状态：`FROZEN_AFTER_REVIEW_REMEDIATION`

本报告只覆盖 Task 5C 小程序页面和数据服务接线，不声明 Task 5 整体完成。

## 已实现范围

- 新增 `pages/table-checkout/index` 公共结账页并在 `miniprogram/app.json` 注册。
- 页面只接受 canonical 128-bit unpadded base64url direct `token`，或解码后严格等于 `t=<token>` 的 `scene`；末字符仅允许 `A/Q/g/w`，其它 22 字符 lookalike 在服务调用前拒绝。
- `miniprogram/services/data.js` 新增：
  - `getTableCheckoutOrder({token})`
  - `createTablePayOrder({token})`
- 两个接口都走 `callCheckedCloud`；云未就绪时返回 `CLOUD_NOT_READY`，不使用 mock 支付数据。
- 页面显式筛选公开订单字段，渲染球厅、球桌、起止时间、计费时长、公开价格/优惠/应付金额及订单状态，不保留或展示服务端额外内部字段。
- 支付按钮用实例锁和 UI 状态双重防重复点击，只向 `wx.requestPayment` 转发五个签名字段。
- `success`、取消/失败对应的 `fail`、`complete` 使用同一幂等回调；客户端回调只启动最多 8 次的服务端状态读取，不在本地写入 `paid`、关台或外部结算状态。
- 普通 load、retry、hide→show 刷新和轮询读取共用一个单调递增的 request generation；只有最新发出的读取可更新订单，`onHide`、`onUnload` 会作废全部在途读取。
- `onHide`、`onUnload` 清理轮询定时器，并以 polling generation 隔离 timer/in-flight Promise，防止页面隐藏后重新挂定时器。

## TDD 证据

RED 命令使用仓库指定的 Codex Node 运行时：

```powershell
& 'C:\Users\15384\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe' .\tests\tableCheckoutPageContract.test.js
```

生产代码修改前实际失败：

```text
TypeError: data.getTableCheckoutOrder is not a function
at testDataServiceUsesOnlyFailClosedCloudCalls (...tableCheckoutPageContract.test.js:132:14)
Exit code: 1
```

GREEN 实现后同一 focused 测试实际输出：

```text
table checkout page contract ok
Exit code: 0
```

契约测试覆盖：canonical token/scene 入口、公开字段白名单、云未就绪 fail closed、精确云函数参数、五字段支付调用、双击防护、任一支付回调只进入服务端轮询、服务端确认前不显示 paid、统一订单读取 generation、轮询上限及 hide/unload timer/在途响应清理。

## 独立复审整改 TDD

统一订单读取 generation 的 RED 同时复现了普通 load/retry、hide→show 和轮询竞态。较新的服务端 `paid` 先返回后，三个较旧的 `unpaid/canPay:true` 响应都会覆盖页面：

```text
AssertionError: Only the newest ordinary, retry, hide/show, or polling response may update page state.
actual:   [ 'unpaid', 'unpaid', 'unpaid', null ]
expected: [ 'paid',   'paid',   'paid',   null ]
Exit code: 1
```

实现统一 generation 后，同一 focused 测试转为 exit code 0；`onHide`/`onUnload` 通过递增 generation 主动作废在途响应。

端侧 canonical token 的独立 RED 使用了字符集和长度都合法、但末位 padding bits 非零的 lookalike：

```text
AssertionError: Expected values to be strictly equal:
actual:   'AAAAAAAAAAAAAAAAAAAAAB'
expected: ''
Exit code: 1
```

将 token 规则收紧为 `^[A-Za-z0-9_-]{21}[AQgw]$` 后，同一 focused 测试转为 exit code 0，并显式覆盖四个合法末字符以及 direct/scene 两种入口。

## 微信支付边界复核

按项目微信支付 Skill 的本地官方知识库复核了服务商 APIv3 小程序支付：

- [开发指引](https://pay.weixin.qq.com/doc/v3/partner/4012076732.md)要求前端按钮防重复点击，并在用户完成、取消或失败返回后由后端查单确认状态。
- [小程序调起支付](https://pay.weixin.qq.com/doc/v3/partner/4012085827.md)定义 `timeStamp`、`nonceStr`、`package`、`signType`、`paySign` 五个字段，并明确前端回调不绝对可靠，订单状态以后端查单和支付成功通知为准。

实现与上述边界一致。知识库同步脚本未运行，因为本子任务被明确禁止修改 `.agents/**`；只读了仓库现有文档，未改动知识库。

## Focused 验证

最后一次阶段验证结果：

```text
table checkout page contract ok
SYNTAX=PASS FILE=.\tests\tableCheckoutPageContract.test.js
SYNTAX=PASS FILE=.\miniprogram\pages\table-checkout\index.js
SYNTAX=PASS FILE=.\miniprogram\services\data.js
JSON=PASS FILE=.\miniprogram\app.json
JSON=PASS FILE=.\miniprogram\pages\table-checkout\index.json
```

未运行全量测试或 `scripts/codex-verify.ps1`；按任务约束留给根任务最终收口。

## 范围与交接

- 未修改任何 cloud function。
- 未删除任何文件。
- 未修改 `.agents/**`。
- 未运行 Git 命令、未暂存或提交。
- `scripts/codex-context.ps1` 返回 `NEW_TASK_RECOMMENDED`；`scripts/codex-status.ps1` 因仓库当前没有单一 revision 返回 `fatal: Needed a single revision`。本子任务没有权限修改 `docs/codex/HANDOFF.md`，由根任务决定是否处理该提示。

Task 5C 已完成本轮独立复审整改并再次冻结，交由根任务统一收口。
