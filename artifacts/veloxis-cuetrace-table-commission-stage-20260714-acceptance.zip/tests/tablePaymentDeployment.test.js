const assert = require('assert');
const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');

const cloudFunctions = Object.freeze([
  'saveShopStore',
  'createSession',
  'getSessions',
  'closeSession',
  'createTableOrder',
  'markTableOrderExternalPaid',
  'getTableCheckoutOrder',
  'genTableCheckoutCode',
  'createTablePayOrder',
  'tablePayNotifyV3',
  'reconcileTablePayments',
  'settleTableProfitSharing',
  'requestTableRefund',
  'tableRefundNotifyV3',
  'reconcileTableFinance',
  'getTodayRevenue',
  'getShopBizOverview'
]);

const timerContracts = Object.freeze({
  reconcileTablePayments: {
    name: 'reconcileTablePaymentsTimer',
    config: '0 */5 * * * * *'
  },
  settleTableProfitSharing: {
    name: 'settleTableProfitSharingTimer',
    config: '0 */5 * * * * *'
  },
  requestTableRefund: {
    name: 'reconcileTableRefundsTimer',
    config: '0 */5 * * * * *'
  },
  reconcileTableFinance: {
    name: 'reconcileTableFinanceTimer',
    config: '0 15 10 * * * *'
  }
});

const requiredEnvironmentVariables = Object.freeze([
  'WXPAY_V3_ENABLED',
  'WXPAY_SP_APPID',
  'WXPAY_SP_MCHID',
  'WXPAY_MERCHANT_SERIAL_NO',
  'WXPAY_MERCHANT_PRIVATE_KEY',
  'WXPAY_API_V3_KEY',
  'WXPAY_PLATFORM_CERTS_JSON',
  'WXPAY_TABLE_NOTIFY_URL',
  'WXPAY_TABLE_REFUND_NOTIFY_URL',
  'WXPAY_PLATFORM_RECEIVER_NAME',
  'WXPAY_ENCRYPTION_KEY_ID'
]);

const requiredCollections = Object.freeze([
  'accounts',
  'wechat_bindings',
  'users',
  'sessions',
  'table_occupancies',
  'stores',
  'shop_orders',
  'shop_payment_profiles',
  'financial_events',
  'shop_refunds',
  'wechat_bill_artifacts',
  'finance_reconciliation_runs',
  'finance_anomalies',
  'billing_policies'
]);

function full(relativePath) {
  return path.join(root, relativePath);
}

function read(relativePath) {
  return fs.readFileSync(full(relativePath), 'utf8');
}

function parseJson(relativePath) {
  return JSON.parse(read(relativePath));
}

function walkFiles(directory, predicate, files = []) {
  for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
    if (['.agents', '.git', 'node_modules'].includes(entry.name)) continue;
    const filename = path.join(directory, entry.name);
    if (entry.isDirectory()) walkFiles(filename, predicate, files);
    else if (predicate(filename)) files.push(filename);
  }
  return files;
}

function assertAllBusinessJsonParses() {
  const jsonFiles = [
    full('project.config.json'),
    full('project.private.config.json'),
    ...walkFiles(full('cloudfunctions'), (filename) => filename.endsWith('.json')),
    ...walkFiles(full('miniprogram'), (filename) => filename.endsWith('.json'))
  ];
  for (const filename of jsonFiles) {
    JSON.parse(fs.readFileSync(filename, 'utf8'));
  }
}

function assertProductionArtifactsAndJson() {
  for (const name of cloudFunctions) {
    const directory = full(path.join('cloudfunctions', name));
    assert(fs.statSync(directory).isDirectory(), `${name} cloud function must exist.`);
    assert(fs.statSync(path.join(directory, 'index.js')).isFile(), `${name}/index.js must exist.`);
    const packageJson = JSON.parse(fs.readFileSync(path.join(directory, 'package.json'), 'utf8'));
    assert.strictEqual(packageJson.main, 'index.js', `${name} package main must be index.js.`);
    assert(packageJson.dependencies && packageJson.dependencies['wx-server-sdk'], `${name} must declare wx-server-sdk.`);
  }

  const pageDirectory = full('miniprogram/pages/table-checkout');
  for (const extension of ['js', 'json', 'wxml', 'wxss']) {
    assert(fs.statSync(path.join(pageDirectory, `index.${extension}`)).isFile());
  }
  const app = parseJson('miniprogram/app.json');
  assert(app.pages.includes('pages/table-checkout/index'));
  for (const page of ['shop/hall-status', 'shop/biz-data']) {
    for (const extension of ['js', 'json', 'wxml', 'wxss']) {
      assert(fs.statSync(full(`miniprogram/pages/${page}/index.${extension}`)).isFile());
    }
  }

  const jsonFiles = [
    'miniprogram/app.json',
    'miniprogram/pages/table-checkout/index.json',
    ...cloudFunctions.map((name) => `cloudfunctions/${name}/package.json`),
    ...Object.keys(timerContracts).map((name) => `cloudfunctions/${name}/config.json`)
  ];
  for (const filename of jsonFiles) parseJson(filename);
}

function assertDeployedImportsStayInsideFunction() {
  for (const name of cloudFunctions) {
    const directory = full(path.join('cloudfunctions', name));
    const prefix = directory.toLowerCase() + path.sep;
    const scripts = walkFiles(directory, (filename) => filename.endsWith('.js'));
    for (const filename of scripts) {
      const source = fs.readFileSync(filename, 'utf8');
      const imports = source.matchAll(/require\(\s*['"](\.{1,2}\/[^'"]+)['"]\s*\)/g);
      for (const match of imports) {
        const resolved = path.resolve(path.dirname(filename), match[1]);
        assert(
          (resolved.toLowerCase() + path.sep).startsWith(prefix),
          `${path.relative(root, filename)} imports outside its deployment directory: ${match[1]}`
        );
        assert(
          fs.existsSync(resolved) || fs.existsSync(`${resolved}.js`) || fs.existsSync(path.join(resolved, 'index.js')),
          `${path.relative(root, filename)} has an unresolved local import: ${match[1]}`
        );
      }
    }
  }
}

function assertCanonicalCopyGate() {
  const sync = read('scripts/sync-table-finance-libs.ps1');
  const parity = read('tests/cloudSharedParity.test.js');
  assert(sync.includes('$CopyAllowlist'));
  assert(sync.includes('This script does not accept destination or path arguments.'));
  assert(parity.includes('must byte-match'));
  for (const name of [
    'createTablePayOrder',
    'tablePayNotifyV3',
    'reconcileTablePayments',
    'settleTableProfitSharing',
    'requestTableRefund',
    'tableRefundNotifyV3',
    'reconcileTableFinance'
  ]) {
    assert(sync.includes(`cloudfunctions/${name}/lib/`), `${name} must be in the literal sync allowlist.`);
    assert(parity.includes(`cloudfunctions/${name}/lib/`), `${name} must be in the parity allowlist.`);
  }

  const adapter = read('cloudfunctions/_shared/wechatpay-v3/client.js');
  assert(adapter.includes('AI 参考官方 Java 翻译生成，非官方维护。'));
  assert(adapter.includes('上线前充分测试'));
}

function assertExactTimersAndRetiredTriggers() {
  for (const [name, expected] of Object.entries(timerContracts)) {
    const config = parseJson(`cloudfunctions/${name}/config.json`);
    assert.deepStrictEqual(config.triggers, [{
      name: expected.name,
      type: 'timer',
      config: expected.config
    }]);
  }

  for (const name of ['createRecurringDebit', 'reconcilePay']) {
    const config = parseJson(`cloudfunctions/${name}/config.json`);
    assert.deepStrictEqual(config.triggers || [], [], `${name} must have no active trigger.`);
    const source = read(`cloudfunctions/${name}/index.js`);
    assert(source.includes('PRODUCT_RETIRED'), `${name} must fail closed as retired.`);
  }
}

function assertNoEmbeddedSecrets() {
  const roots = [
    full('cloudfunctions'),
    full('miniprogram'),
    full('scripts'),
    full('docs/table-commission-deployment.md'),
    full('README.md')
  ];
  const files = [];
  for (const target of roots) {
    if (fs.statSync(target).isDirectory()) {
      walkFiles(target, (filename) => /\.(?:js|json|ps1|md)$/.test(filename), files);
    } else {
      files.push(target);
    }
  }
  const privateKey = /-----BEGIN (?:RSA )?PRIVATE KEY-----/;
  const bearerCredential = /\bBearer\s+[A-Za-z0-9._~+/-]{20,}={0,2}\b/;
  const assignedApiKey = /WXPAY_API_V3_KEY\s*[=:]\s*['"](?!<|\$\{|process\.env)[^'"]{16,}['"]/;
  for (const filename of files) {
    const source = fs.readFileSync(filename, 'utf8');
    assert(!privateKey.test(source), `${path.relative(root, filename)} embeds a private key.`);
    assert(!bearerCredential.test(source), `${path.relative(root, filename)} embeds a bearer credential.`);
    assert(!assignedApiKey.test(source), `${path.relative(root, filename)} embeds an APIv3 key.`);
  }
}

function assertClientAndCallbackBoundaries() {
  const data = read('miniprogram/services/data.js');
  const checkout = read('miniprogram/pages/table-checkout/index.js');
  const hall = read('miniprogram/pages/shop/hall-status/index.js');
  const client = `${data}\n${checkout}\n${hall}`;
  assert(!client.includes("collection('financial_events')"));
  assert(!client.includes("collection('shop_refunds')"));
  assert(!/paymentStatus\s*:\s*['"]paid['"]/.test(checkout));
  assert(!/createTableOrder\(\s*\{[^}]*\b(?:amount|price|storeId|tableId|payerOpenid|subMchid)\b/s.test(hall));

  for (const name of ['tablePayNotifyV3', 'tableRefundNotifyV3']) {
    const callback = read(`cloudfunctions/${name}/index.js`);
    assert(callback.includes('extractWechatPayEvent'));
    assert(callback.includes('rawBody'));
    assert(callback.includes('verifyWechatPaySignature'));
    const httpEvent = read(`cloudfunctions/${name}/lib/wechatpay-v3/http-event.js`);
    for (const header of [
      'wechatpay-timestamp',
      'wechatpay-nonce',
      'wechatpay-serial',
      'wechatpay-signature'
    ]) {
      assert(httpEvent.includes(header), `${name} must preserve ${header}.`);
    }
  }
}

function assertOperatorDocumentation() {
  const deployment = read('docs/table-commission-deployment.md');
  for (const token of requiredEnvironmentVariables) assert(deployment.includes(token), `Missing ${token} documentation.`);
  for (const token of requiredCollections) assert(deployment.includes(`\`${token}\``), `Missing ${token} collection documentation.`);
  for (const expected of Object.values(timerContracts)) {
    assert(deployment.includes(`\`${expected.name}\``));
    assert(deployment.includes(`\`${expected.config}\``));
  }
  for (const token of [
    '普通服务商',
    '特约商户',
    '分账授权',
    'SERVICE_PROVIDER',
    'HTTPS',
    'Wechatpay-Timestamp',
    'Wechatpay-Nonce',
    'Wechatpay-Serial',
    'Wechatpay-Signature',
    'finance/bills/{date}/{subMchid}/trade.csv',
    'finance/bills/**',
    'storageVisibility',
    '最小权限',
    '回滚',
    '5%',
    'T+1',
    '真实小额支付',
    '真实资金验收'
  ]) {
    assert(deployment.includes(token), `Deployment guide must document ${token}.`);
  }
  assert(/finance\/bills\/\*\*[^\n]*客户端读取拒绝[^\n]*客户端写入拒绝/.test(deployment));
  assert(/shop_payment_profiles[^\n]*paymentEnabled[^\n]*profitSharingEnabled[^\n]*tradeBillModeVerified/.test(deployment));
  assert(/shop_payment_profiles[^\n]*subMchid ASC[^\n]*唯一/.test(deployment));
  assert(deployment.includes('历史订单的缺失/空值不能用于唯一索引'));
  assert(deployment.includes('启用支付档案总数不得超过 100'));
  assert(deployment.includes('每个 `subMchid` 每个北京时间自然日的订单数和退款数分别不得超过 100'));
  assert(deployment.includes('超过任一门槛前必须先上线游标分页'));
  assert(/shop_orders` token[^\n]*checkoutTokenHash ASC[^\n]*普通/.test(deployment));
  assert(/shop_orders` 商户支付单号[^\n]*outTradeNo ASC[^\n]*普通/.test(deployment));
  assert(!/shop_orders` (?:token|商户支付单号)[^\n]*\| 唯一/.test(deployment));
  assert(/schemaVersion ASC[^\n]*orderStatus ASC[^\n]*paymentStatus ASC[^\n]*paymentBillFeeEvidence ASC[^\n]*paymentBillDiscoveryCompletedAt ASC[^\n]*paidAt ASC[^\n]*_id ASC/.test(deployment));
  assert(/checkoutTokenHash[^\n]*outTradeNo[^\n]*wechatTransactionId/.test(deployment));
  assert(/schemaVersion[^\n]*orderStatus[^\n]*checkoutAt/.test(deployment));
  assert(/subMchid[^\n]*paymentStatus[^\n]*splitStatus[^\n]*paidAt/.test(deployment));
  assert(/orderId[^\n]*status[^\n]*refundNo/.test(deployment));
  assert(/orderId[^\n]*eventType[^\n]*createdAt/.test(deployment));
  assert(/status[^\n]*billDate[^\n]*severity/.test(deployment));
  assert(/shopId[^\n]*storeId[^\n]*status/.test(deployment));

  const readme = read('README.md');
  assert(readme.includes('docs/table-commission-deployment.md'));
  assert(readme.includes('按桌抽成'));
  assert(readme.includes('真实资金'));
  assert(readme.includes('连续订阅创建与扣费已退役'));

  const recurringArchive = read('docs/shop-recurring-subscription-setup.md');
  assert(recurringArchive.startsWith('# 历史归档'));
  assert(recurringArchive.includes('PRODUCT_RETIRED'));
  assert(recurringArchive.includes('禁止部署'));
}

function main() {
  assertAllBusinessJsonParses();
  assertProductionArtifactsAndJson();
  assertDeployedImportsStayInsideFunction();
  assertCanonicalCopyGate();
  assertExactTimersAndRetiredTriggers();
  assertNoEmbeddedSecrets();
  assertClientAndCallbackBoundaries();
  assertOperatorDocumentation();
  console.log('table payment deployment contract ok');
}

main();
