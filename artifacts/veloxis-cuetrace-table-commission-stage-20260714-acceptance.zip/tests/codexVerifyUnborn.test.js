const assert = require('assert');
const fs = require('fs');
const path = require('path');

const verifierPath = path.resolve(__dirname, '../scripts/codex-verify.ps1');
const verifier = fs.readFileSync(verifierPath, 'utf8');

function testVerifierDetectsHeadWithoutFailing() {
  assert(
    verifier.includes("Invoke-Git @('rev-parse', '--verify', 'HEAD') -AllowFailure"),
    'verifier should probe HEAD with an allowed failure for unborn repositories'
  );
}

function testVerifierBranchesForNormalAndUnbornRepositories() {
  const branch = verifier.match(
    /if \(\$headResult\.ExitCode -eq 0\)\s*\{[\s\S]*?'merge-base'[\s\S]*?'diff', '--name-only'[\s\S]*?'diff', '--check'[\s\S]*?\}\s*else\s*\{[\s\S]*?\$tracked = @\(\)[\s\S]*?\$diffOutput = @\(\)[\s\S]*?\}/
  );

  assert(
    branch,
    'verifier should keep merge-base checks with HEAD and clear tracked/diff data without HEAD'
  );
}

function testVerifierStillCollectsUntrackedFiles() {
  const headProbe = verifier.indexOf("'rev-parse', '--verify', 'HEAD'");
  const untrackedCollection = verifier.indexOf("'ls-files', '--others'");

  assert(headProbe >= 0, 'HEAD probe should exist');
  assert(
    untrackedCollection > headProbe,
    'untracked files should still be collected after HEAD detection'
  );
}

testVerifierDetectsHeadWithoutFailing();
testVerifierBranchesForNormalAndUnbornRepositories();
testVerifierStillCollectsUntrackedFiles();

console.log('codex verifier unborn support ok');
